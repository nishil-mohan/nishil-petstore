import {ChangeDetectionStrategy, Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {Subscription} from 'rxjs/Subscription';

 

@Component({
  selector: 'super-cart',
  styleUrls: ['./super-cart.style.scss'],
  templateUrl: './super-cart.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SuperCartComponent implements OnInit, OnDestroy {
   

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  constructor(private router: Router) {
    
  }

  ngOnInit() {
    // Run on component initialization
  }

  goBack() {
    // no logic yet
    this.router.navigate(['/upsell']);
  }

  goNext() {
    // no logic yet
    this.router.navigate(['/traveler']);
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
