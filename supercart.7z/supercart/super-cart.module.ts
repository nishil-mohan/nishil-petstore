import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {CartContModule} from '@otter/components';

import {SuperCartComponent} from './super-cart.component';

 

@NgModule({
  imports: [
    RouterModule.forChild([{path: '', component: SuperCartComponent}]),
    CommonModule,

    // Fare page components
    CartContModule
  ],
  declarations: [SuperCartComponent],
  exports: [SuperCartComponent]
  
})
export class SuperCartModule {}
