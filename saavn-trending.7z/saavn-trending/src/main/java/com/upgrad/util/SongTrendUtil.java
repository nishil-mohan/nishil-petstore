package com.upgrad.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.mortbay.util.StringUtil;

public class SongTrendUtil {

	public static void main(String[] args) {

		String fileName = "C://upgrad//project//saavn//New folder//part1";

		//read file into stream, try-with-resources
		try (Stream<String> stream = Files.lines(Paths.get(fileName))) {
			List<SongTrendOutput> trends=new ArrayList<SongTrendOutput>();
			stream.forEach(line->{
				SongTrendOutput output=new SongTrendOutput();
				trends.add(output);
				String[]lineSplit=line.split("::");
				output.setSongId(StringUtils.trim(lineSplit[0]));
				output.setDay(StringUtils.trim(lineSplit[1]));
				output.setCount(Integer.parseInt(StringUtils.trim(lineSplit[3])));
			});
			trends.sort((e1,e2)->{
				if(e1.getDay().compareTo(e2.getDay())==0) {
					return Long.compare(e1.getCount(), e2.getCount());
				}else {
					return e1.getDay().compareTo(e2.getDay());
				}
			});
			int rank=0;
			String oldDate=null;
			for(SongTrendOutput out:trends){
				if(oldDate==null || oldDate.equals(out.getDay())) {
					rank=rank+1;
				}else {
					rank=1;
				}
				if(rank<=100) {
					System.out.println(out.getSongId()+",2017-12-"+out.getDay()+","+rank);
				}
				oldDate=out.getDay();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
