package com.upgrad;


import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


/**
 * Algorithm considers 3 days of historical data to compute the trend.
 * 
 * In the Map Phase
 *  1. Parse the data set and filter out data from 01 to 23th (as 2 days of historical data is only considered). This can improve processing time.
 *  2. Any invalid record also will be filtered out.
 *  3. Out intermediate key value pair, with key as song id, and value as the DateCount object which holds day and hour of song id streaming.
 *  
 *  In the combiner Phase
 *  1. Compute the occurrence of a song Id grouped by DateCount object. This will provide total count of a song streamed on a hour+day combination from the chunk processed
 *     by map phase
 *  2. This computation reduces reduce job computation time and can improve the performance.
 *  
 *  Now mapreduce framework will execute shuffle and sort and invokes the reduce job.
 *  
 *  In the reducer Phase
 *  1. Input to reduce job is Song Id (key) and value as Array of DateCount Object.
 *  2. For each day, identify peak hour hit (from 08:AM - 12:00 PM) and previous 2 days hit.
 *  3. Filter out songs which havent received even 500 hits per peak hour and 5% increase from previous day. This can reduce the output file size to great extend.
 * 
 * 
 * @author nishil85
 *
 */
public class SaavnFilter
{

	public static class MapperClass extends Mapper<Object, Text, Text, DateAndCount> 
	{
		int WINDOW_MIN_DAY=25;
		int WINDOW_MAX_DAY=31;
		int WINDOW_TO_ANALYSE=2;

		public void map(Object key, Text record, Context con) throws IOException, InterruptedException 
		{
			int IGNORE_DAY_BEFORE=WINDOW_MIN_DAY-WINDOW_TO_ANALYSE;
			String[] info = record.toString().split(",");
			if(info.length>=4) {
				String songid = info[0];
				String[] date = info[4].split("-");
				if(date.length>1){
					try {
						int hour=Integer.parseInt(info[3]);
						int day=Integer.parseInt(date[2]);
						if(day>=IGNORE_DAY_BEFORE && day<=WINDOW_MAX_DAY) {
							con.write(new Text(songid), new DateAndCount(day,hour,1));
						}

					}catch(Exception e) {
						//Suppressing the exception caused due to invalid/missing entries in records.
						//Invalid entries will be ignored
					}

				}
			}
		}
	}


	public static class CombinerClass extends Reducer<Text, DateAndCount, Text, DateAndCount> 
	{

		public void reduce(Text key, Iterable<DateAndCount> valueList, 
				Context con) throws IOException, InterruptedException 
		{
			Map<String, Long>countMap=new HashMap<String, Long>();
			for (DateAndCount var : valueList) 
			{
				String dayKey=var.getHour()+"-"+var.getDay();
				countMap.merge(dayKey, new Long(1), Long::sum);
			}
			countMap.forEach((dateKey,dateValue)->{
				String[] dayTkn=dateKey.split("-");
				DateAndCount dateAndCountMerged=new DateAndCount(Integer.parseInt(dayTkn[1]), Integer.parseInt(dayTkn[0]), dateValue);
				try {
					con.write(key, dateAndCountMerged);
				} catch (IOException | InterruptedException e) {
					//Suppress the exception
				}
			});
		}
	}



	public static class ReducerClass extends Reducer<Text, DateAndCount, Text, Text> 
	{
		int minCountThreshold=500; //If count for last 4 hours <100, dont consider as trending and filter it out
		double minTrendRate=0.05;  //only consider as trending if stream increases atleast 5% per day

		public void reduce(Text key, Iterable<DateAndCount> valueList,Context con) throws IOException, InterruptedException 
		{
			Map<Integer, TrendCount>dayCountMap=new HashMap<Integer, TrendCount>();
			for (DateAndCount dateCount : valueList) 
			{
				dayCountMap.merge(dateCount.getDay(),new TrendCount(dateCount.getDay()), (k,v)->updateTrendStats(k,dateCount));
			}

			dayCountMap.forEach((day,trend)->{
				try {
					//Ignore songs, which havent received even x hits in peak hour and not increment in hit ratio from past 3 days
					if(trend.getPeakHourCount()>=minCountThreshold && isTrendingFromPast2Days(dayCountMap,trend,minTrendRate,minCountThreshold)) {
						con.write(new Text(key.toString()+"::"+day), new Text("::"+trend.getPeakHourCount()+"::"+trend.getDayCount()));
					}

				} catch (IOException | InterruptedException e) {
					//Suppress the exception
				}
			});

		}

		/**
		 * 
		 * @param inital
		 * @param dateAndCount
		 * @return
		 */
		private TrendCount updateTrendStats(TrendCount inital,DateAndCount dateAndCount) {
			int hour=dateAndCount.getHour();
			if(hour>=8 && hour<=12) {
				inital.incrementPeakHourCount(dateAndCount.getCount());
			}
			inital.incrementDayCount(dateAndCount.getCount());
			return inital;
		}


		/**
		 * 
		 * @param dayCountMap
		 * @param presentTrend
		 * @param minTrendRate
		 * @return
		 * @throws IOException 
		 */
		private boolean isTrendingFromPast2Days(Map<Integer, TrendCount> dayCountMap, TrendCount presentTrend,double minTrendRate,int minCountThreshold) {
			int presentDay=presentTrend.getDay();
			Long presentDayHit=presentTrend.getDayCount();
			boolean pastDayRecordExist=false;
			for(int i=1;i<=2;i++) { //Checkin for past 2 days
				TrendCount pastTrend=dayCountMap.get(presentDay-i);
				if(pastTrend!=null) {
					Long hitsPastDay=pastTrend.getDayCount();
					if(hitsPastDay>minCountThreshold) {
						pastDayRecordExist=true;
						double trendRate=i*minTrendRate;
						if((double)(presentDayHit-hitsPastDay)/presentDayHit<trendRate) {
							return false;
						}
					}

				}
			}
			if(!pastDayRecordExist) { //if atleast one history is not present, dont consider as trending
				return false;
			}
			//Can be marked as trending, as for past 3 days, there is increase in hit
			return true;
		}
	}



	public static void main(String[] args) throws Exception 
	{
		Configuration conf;
		Job job;

		conf = new Configuration();

		job = Job.getInstance(conf, "Saavn_Trending_Job");
		job.setJarByClass(SaavnFilter.class);

		job.setMapperClass(MapperClass.class);
		job.setReducerClass(ReducerClass.class);
		job.setCombinerClass(CombinerClass.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(DateAndCount.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));

		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
