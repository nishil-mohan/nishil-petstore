package com.upgrad;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableUtils;


public class DateAndCount implements Writable {
	int day;
	int hour;
	long count;

	public DateAndCount() {super();}

	public DateAndCount(int day, int hour, long count) {
	    this.day = day;
	    this.hour = hour;
	    this.count = count;
	}

	public void readFields(DataInput dataInput) throws IOException {
		day = WritableUtils.readVInt(dataInput);
		hour = WritableUtils.readVInt(dataInput);    
	    count = WritableUtils.readVLong(dataInput);     
	}

	public void write(DataOutput dataOutput) throws IOException {
	    WritableUtils.writeVInt(dataOutput, day);
	    WritableUtils.writeVInt(dataOutput, hour);
	    WritableUtils.writeVLong(dataOutput, count);
	}

	/**
	 * @return the day
	 */
	public int getDay() {
		return day;
	}

	/**
	 * @param day the day to set
	 */
	public void setDay(int day) {
		this.day = day;
	}

	/**
	 * @return the hour
	 */
	public int getHour() {
		return hour;
	}

	/**
	 * @param hour the hour to set
	 */
	public void setHour(int hour) {
		this.hour = hour;
	}

	/**
	 * @return the count
	 */
	public long getCount() {
		return count;
	}

	/**
	 * @param count the count to set
	 */
	public void setCount(long count) {
		this.count = count;
	}
	
	

}
