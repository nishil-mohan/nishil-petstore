package com.upgrad;

import java.io.Serializable;


public class TrendCount implements Serializable {
	private int day;
	
	private Long peakHourCount=new Long(0);

	private Long dayCount=new Long(0);
	
	private double ratio;

	public TrendCount(int day) {
		this.day=day;
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the day
	 */
	public int getDay() {
		return day;
	}

	/**
	 * @param day the day to set
	 */
	public void setDay(int day) {
		this.day = day;
	}

	/**
	 * @return the peakHourCount
	 */
	public Long getPeakHourCount() {
		return peakHourCount;
	}

	/**
	 * @param peakHourCount the peakHourCount to set
	 */
	public void setPeakHourCount(Long peakHourCount) {
		this.peakHourCount = peakHourCount;
	}
	
	/**
	 * 
	 */
	public void incrementPeakHourCount(Long count) {
		if(count!=null) {
			peakHourCount=peakHourCount+count;
		}
	}

	/**
	 * @return the dayCount
	 */
	public Long getDayCount() {
		return dayCount;
	}
	
	/**
	 * @param dayCount the dayCount to set
	 */
	public void setDayCount(Long dayCount) {
		this.dayCount = dayCount;
	}
	
	public void incrementDayCount(Long count) {
		if(count!=null) {
			dayCount=dayCount+count;
		}
	}

	/**
	 * @return the ratio
	 */
	public double getRatio() {
		return ratio;
	}

	/**
	 * @param ratio the ratio to set
	 */
	public void setRatio(double ratio) {
		this.ratio = ratio;
	}

	@Override
	public String toString() {
		return "TrendCount [day=" + day + ", " + (peakHourCount != null ? "peakHourCount=" + peakHourCount + ", " : "")
				+ (dayCount != null ? "dayCount=" + dayCount + ", " : "") + "ratio=" + ratio + "]";
	}
	
	
}
