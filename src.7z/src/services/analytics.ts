import {ROUTER_NAVIGATION, RouterNavigationAction} from '@ngrx/router-store';
import {Action, ActionReducer} from '@ngrx/store';
import {AirSearchCriteria} from '@otter/store';

import {createMetaReducer} from 'redux-beacon';
import {Event, GoogleAnalytics, PageView} from 'redux-beacon/targets/google-analytics';

/** Page view event */
const pageView = (action: RouterNavigationAction): PageView => ({
  hitType: 'pageview',
  page: action.payload.routerState.url
});

/** Search Flight event */
const searchFlight = (action: AirSearchCriteria.Actions.AddAndSelect): Event => ({
  hitType: 'event',
  eventCategory: 'search',
  eventAction: 'search flight',
  eventLabel: JSON.stringify(action.payload)
});

/** Map the event to a ngrx/store action */
const eventsMap: {[action: string]: ActionReducer<any>} = {};
eventsMap[ROUTER_NAVIGATION] = pageView;
eventsMap['[AirSearchCriteria] update'] = searchFlight;

const analyticsReducer = createMetaReducer(eventsMap, GoogleAnalytics);

/** Meta reducer to report changes on Google Analytics */
export function analyticsMetaReducer<T, V extends Action = Action>(reducer: ActionReducer<T, V>): ActionReducer<T, V> {
  return analyticsReducer(reducer);
}
