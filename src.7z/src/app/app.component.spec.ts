import {Component, DebugElement, Directive} from '@angular/core';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserModule, By} from '@angular/platform-browser';
import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from '@angular/platform-browser-dynamic/testing';
import {RouterTestingModule} from '@angular/router/testing';
import {TranslateModule} from '@ngx-translate/core';
import {LocalizationModule} from '@otter/common';
import {LocalizationConfiguration} from '@otter/core';
import {AppComponent} from './app.component';

TestBed.initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting());

@Component({
  selector: 'o3r-simple-header-pres',
  template: ''
})
class MockSimpleHeader {}

@Component({
  selector: 'o3r-list-inline-messages-cont',
  template: ''
})
class MockListInlineMessages {}

@Component({
  selector: 'o3r-spinner-booking-3d',
  template: ''
})
class MockO3rSpinnerBooking3d {}

@Component({
  selector: 'o3r-footer-pres',
  template: ''
})
class MockO3rFooterPres {}

@Directive({
  selector: '[o3r-text-direction]'
})
class TextDirectionDirectiveMock {}

let fixture: ComponentFixture<AppComponent>;

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AppComponent, MockSimpleHeader, MockListInlineMessages, MockO3rSpinnerBooking3d, MockO3rFooterPres, TextDirectionDirectiveMock],
      imports: [
        BrowserModule,
        RouterTestingModule,
        LocalizationModule.forRoot(() => {
          return new LocalizationConfiguration([]);
        }),
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
  });

  it("Should display the app's default display", () => {
    const titleDebugElement: DebugElement = fixture.debugElement.query(By.css('.container-fluid'));
    expect(titleDebugElement.nativeElement.innerText).toBeDefined();
  });
});
