import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, Resolve} from '@angular/router';
import {AirSearchCriteriaService} from '@otter/services';

@Injectable()
export class SearchResolver implements Resolve<any> {
  constructor(public searchCriteriaService: AirSearchCriteriaService) {}

  resolve(route: ActivatedRouteSnapshot) {
    this.searchCriteriaService.clearSearchCriteria();
    return route.queryParams;
  }
}
