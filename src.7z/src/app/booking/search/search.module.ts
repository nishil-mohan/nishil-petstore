import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {SearchComponent} from './search.component';
import {SearchConfig} from './search.config';
import {SearchResolver} from './search.resolver';

import {AirSearchContModule} from '@otter/components';

@NgModule({
  imports: [
    RouterModule.forChild([{path: '', component: SearchComponent, resolve: {queryParam: SearchResolver}}]),
    CommonModule,

    // search page components:
    AirSearchContModule
  ],
  declarations: [SearchComponent],
  exports: [SearchComponent],
  providers: [SearchConfig, SearchResolver]
})
export class SearchModule {}
