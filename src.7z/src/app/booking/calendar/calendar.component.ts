import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Configurable} from '@otter/core';
import {AirCalendarService, AirSearchCriteriaService} from '@otter/services';

import {Subscription} from 'rxjs/Subscription';

import {CalendarConfig} from './calendar.config';

@Component({
  selector: 'o3r-calendar',
  styleUrls: ['./calendar.style.scss'],
  templateUrl: './calendar.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CalendarComponent implements OnInit, OnDestroy, Configurable<CalendarConfig> {
  /**
   * Configuration of the component
   * @Input
   */
  @Input() public config: CalendarConfig;

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  constructor(config: CalendarConfig, private router: Router, public airCalendarService: AirCalendarService, public searchCriteriaService: AirSearchCriteriaService) {
    this.config = config;
  }

  ngOnInit() {
    // Run on component initialization
  }

  goBack() {
    // no logic for now
    this.router.navigate(['/search']);
  }

  goNext() {
    // no logic for now
    this.router.navigate(['/upsell']);
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
