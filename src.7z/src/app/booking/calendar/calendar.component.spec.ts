import {DebugElement} from '@angular/core';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserModule, By} from '@angular/platform-browser';
import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from '@angular/platform-browser-dynamic/testing';

import {CalendarComponent} from './calendar.component';
import {CalendarConfig} from './calendar.config';

TestBed.initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting());

let fixture: ComponentFixture<CalendarComponent>;

describe('CalendarComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CalendarComponent],
      imports: [BrowserModule],
      providers: [CalendarConfig]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalendarComponent);
  });

  xit('Should display the component name in a span', () => {
    const titleDebugElement: DebugElement = fixture.debugElement.query(By.css('span'));
    expect(titleDebugElement.nativeElement.innerText).toBe('CalendarComponent, works!');
  });
});
