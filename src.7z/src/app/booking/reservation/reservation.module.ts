import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {ReservationComponent} from './reservation.component';
import {ReservationConfig} from './reservation.config';
import {ReservationResolver} from './reservation.resolver';

@NgModule({
  imports: [
    RouterModule.forChild([
      {
        path: '',
        component: ReservationComponent,
        resolve: {order: ReservationResolver}
      }
    ]),
    CommonModule
  ],
  declarations: [ReservationComponent],
  exports: [ReservationComponent],
  providers: [ReservationConfig, ReservationResolver]
})
export class ReservationModule {}
