import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {CalendarPerBoundContModule, CircularSpinnerModule, UpsellBoundContModule} from '@otter/components';
import {AirOfferModule} from '@otter/services';

import {UpsellComponent} from './upsell.component';
import {UpsellConfig} from './upsell.config';
import { SuperCartService } from '../../../service/super-cart/super-cart.service';

@NgModule({
  imports: [
    RouterModule.forChild([{path: '', component: UpsellComponent}]),
    CommonModule,

    // Upsell page components
    CalendarPerBoundContModule,
    CircularSpinnerModule,
    UpsellBoundContModule,

    // Service
    AirOfferModule
  ],
  declarations: [UpsellComponent],
  exports: [UpsellComponent],
  providers: [UpsellConfig,SuperCartService]
})
export class UpsellModule {}
