import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {utils} from '@dapi/sdk-core';
import {reviveAirSearchCriteria} from '@dapi/sdk/models';
import {Configurable} from '@otter/core';
import {AirCalendarService, AirOfferService, AirSearchCriteriaService, CartService} from '@otter/services';

import {combineLatest, filter, take} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';

import {UpsellConfig} from './upsell.config';
import {SuperCartService} from '../../../service/super-cart/super-cart.service';

@Component({
  selector: 'o3r-upsell',
  styleUrls: ['./upsell.style.scss'],
  templateUrl: './upsell.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UpsellComponent implements OnInit, OnDestroy, Configurable<UpsellConfig> {
  /**
   * Configuration of the component
   * @Input
   */
  @Input() public config: UpsellConfig;

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  constructor(
    config: UpsellConfig,
    private router: Router,
    private offerService: AirOfferService,
    private airCalendarService: AirCalendarService,
    private cartService: CartService,
    private superCartService:SuperCartService,
    public searchCriteriaService: AirSearchCriteriaService
  ) {
    this.config = config;
  }

  ngOnInit() {
    this.subscriptions.push(
      this.airCalendarService.selectedDates$
        .pipe(
          filter((dates) => dates && dates.length > 0),
          combineLatest(this.searchCriteriaService.searchCriteriaInstance$, (dates, searchState) => {
            const searchCriteria = reviveAirSearchCriteria(searchState);
            if (searchCriteria && searchCriteria.bounds && searchCriteria.bounds.length > 0) {
              if (dates[0]) {
                searchCriteria.bounds[0].departureDateTime = new utils.DateTime(dates[0]);
              }
              if (dates[1] && searchCriteria.bounds.length > 1) {
                searchCriteria.bounds[1].departureDateTime = new utils.DateTime(dates[1]);
              }
            }
            return searchCriteria;
          }),
          filter((searchCriteria) => !!searchCriteria)
        )
        .subscribe((searchCriteria) => this.offerService.loadOffers(searchCriteria!))
    );
  }

  /**
   * Callback of the Back button
   */
  goBack() {
    this.searchCriteriaService.searchCriteriaInstance$.pipe(take(1), filter((searchState) => !!searchState)).subscribe((searchState) => {
      this.router.navigate([searchState && searchState.flexibility ? '/calendar' : '/search']);
    });
  }

  /**
   * Callback of the Continue button
   */
  goNext() {
   // this.cartService.clearAllCart();
   // this.addAirOfferToCart();
    this.router.navigate(['/shopping/MDAyTVFNNkdUSFY2NjIwRw']);
  }
/**
   * Add Offers to the Super cart
   */
  addAirOfferToSuperCart() {
    this.offerService.viewedOffer$.pipe(
      take(1),
      filter((viewedOffer) => !!viewedOffer)).subscribe((viewedOffer) =>  
      this.superCartService.addAirOfferToCart(viewedOffer!)
    )
  }
  /**
   * Add Offers to the current cart
   */
  addAirOfferToCart() {
    this.subscriptions.push(this.offerService.viewedOffer$.pipe(take(1), filter((viewedOffer) => !!viewedOffer)).subscribe((viewedOffer) => this.cartService.addAirOfferToCart(viewedOffer!)));
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
