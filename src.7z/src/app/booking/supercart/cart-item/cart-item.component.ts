import {ChangeDetectionStrategy, Component, Input} from '@angular/core';
import {Amount, Cart} from '@dapi/sdk';

@Component({
  selector: 'cart-item',
  templateUrl: 'cart-item.template.html',
  styleUrls: ['cart-item.style.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CartItemComponent {
  @Input() cart: Cart;

  protected cartExpanded: boolean;

  constructor() {
    this.cartExpanded = false;
  }

  getOriginLocation(cart: Cart): string {
    return cart.airOffers ? cart.airOffers[0].offerItems[0].air.bounds[0].originLocationCode : '';
  }

  getDestinationLocation(cart: Cart): string {
    return cart.airOffers ? cart.airOffers[0].offerItems[0].air.bounds[0].destinationLocationCode : '';
  }

  getTotalPrice(cart: Cart): Amount | null {
    const totalPrices = cart.airOffers ? cart.airOffers[0].offerItems[0].prices.totalPrices : null;
    return totalPrices ? totalPrices[0].totalAmount : null;
  }
}
