import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Configurable} from '@otter/core';

import {Subscription} from 'rxjs/Subscription';

import {FareConfig} from './fare.config';

@Component({
  selector: 'o3r-fare',
  styleUrls: ['./fare.style.scss'],
  templateUrl: './fare.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FareComponent implements OnInit, OnDestroy, Configurable<FareConfig> {
  /**
   * Configuration of the component
   * @Input
   */
  @Input() public config: FareConfig;

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  constructor(config: FareConfig, private router: Router) {
    this.config = config;
  }

  ngOnInit() {
    // Run on component initialization
  }

  goBack() {
    // no logic yet
    this.router.navigate(['/upsell']);
  }

  goNext() {
    // no logic yet
    this.router.navigate(['/traveler']);
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
