import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {CartContModule} from '@otter/components';

import {FareComponent} from './fare.component';
import {FareConfig} from './fare.config';
import {FareResolver} from './fare.resolver';

@NgModule({
  imports: [
    RouterModule.forChild([{path: '', component: FareComponent, resolve: {cart: FareResolver}}]),
    CommonModule,

    // Fare page components
    CartContModule
  ],
  declarations: [FareComponent],
  exports: [FareComponent],
  providers: [FareConfig, FareResolver]
})
export class FareModule {}
