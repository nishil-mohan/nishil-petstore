import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {CircularSpinnerModule, GlobalContactsContModule, TravelerContModule} from '@otter/components';

import {TravelerComponent} from './traveler.component';
import {TravelerConfig} from './traveler.config';

@NgModule({
  imports: [
    RouterModule.forChild([{path: '', component: TravelerComponent}]),
    CommonModule,

    // Traveler page component
    CircularSpinnerModule,
    GlobalContactsContModule,
    TravelerContModule
  ],
  declarations: [TravelerComponent],
  exports: [TravelerComponent],
  providers: [TravelerConfig]
})
export class TravelerModule {}
