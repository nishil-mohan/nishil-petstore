import {DebugElement} from '@angular/core';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserModule, By} from '@angular/platform-browser';
import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from '@angular/platform-browser-dynamic/testing';

import {TravelerComponent} from './traveler.component';
import {TravelerConfig} from './traveler.config';

TestBed.initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting());

let fixture: ComponentFixture<TravelerComponent>;

describe('TravelerComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TravelerComponent],
      imports: [BrowserModule],
      providers: [TravelerConfig]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelerComponent);
  });

  xit('Should display the component name in a span', () => {
    const titleDebugElement: DebugElement = fixture.debugElement.query(By.css('span'));
    expect(titleDebugElement.nativeElement.innerText).toBe('TravelerComponent, works!');
  });
});
