import {Component, OnDestroy, OnInit} from '@angular/core';
import {Event, NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router} from '@angular/router';
import {LocalizationService} from '@otter/common';
import {filter} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';

@Component({
  selector: 'app',
  templateUrl: './app.template.html'
})
export class AppComponent implements OnInit, OnDestroy {
  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  /**
   * Loading indicator
   */
  loading: boolean;

  constructor(private router: Router, private localizationService: LocalizationService) {
    this.localizationService.configure();
  }

  ngOnInit() {
    this.subscriptions.push(this.router.events.subscribe((event) => this.setLoadingIndicator(event)));
    this.subscriptions.push(this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((event) => window.scrollTo(0, 0)));
  }

  setLoadingIndicator(event: Event) {
    if (event instanceof NavigationStart) {
      this.loading = true;
    } else if (event instanceof NavigationEnd || event instanceof NavigationCancel || event instanceof NavigationError) {
      this.loading = false;
    }
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
