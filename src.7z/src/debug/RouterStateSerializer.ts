import {Params, RouterStateSnapshot} from '@angular/router';
import {RouterStateSerializer} from '@ngrx/router-store';

/**
 * Interface of a state URL.
 * Simply the Angular object to be serialized (not circular)
 */
export interface RouterStateUrl {
  /** URL of the state */
  url: string;
  /** Params passed to the state */
  queryParams: Params;
}

/**
 * Custom serializer for RouterStore
 */
export class CustomSerializer implements RouterStateSerializer<RouterStateUrl> {
  serialize(routerState: RouterStateSnapshot): RouterStateUrl {
    const {url} = routerState;
    const queryParams = routerState.root.queryParams;

    return {url, queryParams};
  }
}
