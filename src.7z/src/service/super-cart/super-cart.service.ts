import {Injectable} from '@angular/core';
import {CartApi, CartReply, AirOffer} from '@dapi/sdk';
import {Store,MemoizedSelector,createSelector,createFeatureSelector} from '@ngrx/store';
import {Add} from '../../store/shopping-basket/shopping-basket.actions';
import { ShoppingBasketCart, ShoppingBasketState, SuperCartState} from '../../store/shopping-basket/shopping-basket.state';
//import {Cart} from '@otter/store';
import {Observable} from 'rxjs/Observable';
//import { take} from 'rxjs/operators';

export const superCartState: MemoizedSelector<object, SuperCartState> =
     createFeatureSelector('superCart');
 
export const getFirstCartState: MemoizedSelector<object, ShoppingBasketCart> = createSelector(
      superCartState,
      (state: SuperCartState) => state.cartIdList.entities[state.cartIdList.ids[0]]
    );

export const getSecondCartState: MemoizedSelector<object, ShoppingBasketCart> = createSelector(
      superCartState,
      (state: SuperCartState) => state.cartIdList.entities[state.cartIdList.ids[1]]
    );

export const getThirdCartState: MemoizedSelector<object, ShoppingBasketCart> = createSelector(
      superCartState,
      (state: SuperCartState) => state.cartIdList.entities[state.cartIdList.ids[2]]
    );
    
    //state.cartIdList.entities[state.cartIdList.ids[0]]

@Injectable()
export class SuperCartService {
  cart1$: Observable<ShoppingBasketCart>;
  cart2$: Observable<ShoppingBasketCart>;
  cart3$: Observable<ShoppingBasketCart>;

  protected api: CartApi;

  
  // retrievedCart$: Observable<CartReply>;

  constructor(api: CartApi, public store: Store<ShoppingBasketState>) {
    this.api = api;   

    this.cart1$ = this.store.select(getFirstCartState);
    this.cart2$ = this.store.select(getSecondCartState);
    this.cart3$ = this.store.select(getThirdCartState);   
  }
 

  addAirOfferToCart(airOffer:AirOffer){
    this.api.createCart({airOfferId: airOffer.id}).then((res: CartReply) => {
      this.store.dispatch(new Add({id: airOffer.id, data: res.data}));
    });
     
  }

  retrieveCartList(cartIds: string[]) {
    cartIds.forEach(cartId=>{
      this.api.retrieveCart({cartId: cartId}).then((res: CartReply) => {
       // this.store.dispatch(new Add({id: cartId, data: res.data}));
      });
    });
   
    // 002MQLLPQ0VHI20C
    // 002MQLOP4THNU20O
  }
}
