'use strict';

// Polyfills
import 'core-js/client/shim.js';
import 'whatwg-fetch/fetch.js';
import 'zone.js/dist/zone';

import '@otter/styling/dist/css/index.css';

// Global CSS
import './styling/index.scss';

import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

import {AppModule} from './app';

document.addEventListener('DOMContentLoaded', () => platformBrowserDynamic().bootstrapModule(AppModule));
