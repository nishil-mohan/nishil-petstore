import {Action} from '@ngrx/store';
import {ShoppingBasketCart} from './shopping-basket.state';

export enum ShoppingBasketActionTypes {
  ADD = '[Shopping basket] Add cart id',
  LOAD = '[Shopping basket] Load cart data',
  RESET = '[Shopping basket] Reset'
}

export class Add implements Action {
  readonly type = ShoppingBasketActionTypes.ADD;

  constructor(public payload: ShoppingBasketCart) {}
}

export class Load implements Action {
  readonly type = ShoppingBasketActionTypes.LOAD;

  constructor(public payload: ShoppingBasketCart) {}
}

export class Reset implements Action {
  readonly type = ShoppingBasketActionTypes.RESET;

  constructor() {}
}

export declare type ShoppingBasketAction = Add | Reset | Load;
