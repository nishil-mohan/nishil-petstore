import {createEntityAdapter, EntityAdapter} from '@ngrx/entity';

import {ShoppingBasketAction, ShoppingBasketActionTypes} from './shopping-basket.actions';
import {ShoppingBasketCart, ShoppingBasketState} from './shopping-basket.state';

export const adapter: EntityAdapter<ShoppingBasketCart> = createEntityAdapter<ShoppingBasketCart>();

export const initialState: ShoppingBasketState = adapter.getInitialState();

export function shoppingBasketReducer(state: ShoppingBasketState = initialState, action: ShoppingBasketAction): ShoppingBasketState {
  switch (action.type) {
    case ShoppingBasketActionTypes.ADD:
      return adapter.addOne( action.payload, state);
    case ShoppingBasketActionTypes.LOAD: 
   // return adapter.addOne({id: action.payload.id, data: {data: action.payload.data}}, state);
     return adapter.updateOne({id: action.payload.id, changes: {data: action.payload.data}}, state);
    default:
      return state;
  }
}
