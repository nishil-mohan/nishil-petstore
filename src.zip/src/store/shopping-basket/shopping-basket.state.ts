import {Cart} from '@dapi/sdk/models/base/Cart';

import {EntityState} from '@ngrx/entity';
import {ActionReducerMap} from '@ngrx/store';

import {shoppingBasketReducer} from './shopping-basket.reducer';

export interface ShoppingBasketCart {
  id: string;
  data: Cart;
}

export interface ShoppingBasketState extends EntityState<ShoppingBasketCart> {}

export interface State {
  cartIdList: ShoppingBasketState;
}

export const reducers: ActionReducerMap<State> = {
  cartIdList: shoppingBasketReducer
};
