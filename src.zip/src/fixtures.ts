export {AppFixture} from './app/app.fixture';
export {FareFixture} from './app/booking/fare/fare.fixture';
export {SearchFixture} from './app/booking/search/search.fixture';
export {UpsellFixture} from './app/booking/upsell/upsell.fixture';
