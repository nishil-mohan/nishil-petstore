import {Injectable} from '@angular/core';
import {CartApi, CartReply, AirOffer} from '@dapi/sdk';
import {select,Store} from '@ngrx/store';
import {Add} from '../../store/shopping-basket/shopping-basket.actions';
import {State, ShoppingBasketCart} from '../../store/shopping-basket/shopping-basket.state';
//import {Cart} from '@otter/store';
import {Observable} from 'rxjs/Observable';
import { take} from 'rxjs/operators';

@Injectable()
export class SuperCartService {

   
  /**
   * Observable representing the active cart.
   */
  public cart$: Observable<ShoppingBasketCart>;

  cart1$: Observable<ShoppingBasketCart>;
  cart2$: Observable<ShoppingBasketCart>;
  cart3$: Observable<ShoppingBasketCart>;


  protected api: CartApi;

  // retrievedCart$: Observable<CartReply>;

  constructor(api: CartApi, public store: Store<State>) {
    this.api = api;
     
    this.cart$ = store.pipe(select(state=>state.cartIdList.entities.data));

    this.cart1$=this.cart$.pipe(take(1));
    this.cart2$=this.cart$.pipe(take(2));
    this.cart3$=this.cart$.pipe(take(3));
    
     
  }
 

  addAirOfferToCart(airOffer:AirOffer){
    this.api.createCart({airOfferId: airOffer.id}).then((res: CartReply) => {
      this.store.dispatch(new Add({id: airOffer.id, data: res.data}));
    });
     
  }

  retrieveCartList(cartIds: string[]) {
    cartIds.forEach(cartId=>{
      this.api.retrieveCart({cartId: cartId}).then((res: CartReply) => {
        this.store.dispatch(new Add({id: cartId, data: res.data}));
      });
    });
   
    // 002MQLLPQ0VHI20C
    // 002MQLOP4THNU20O
  }
}
