describe('Otter Demo App', () => {
  it('should compile', () => {
    expect(true).toBe(true);
  });
});
