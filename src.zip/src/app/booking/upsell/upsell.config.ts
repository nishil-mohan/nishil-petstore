import {Injectable} from '@angular/core';
import {Configuration} from '@otter/core';

@Injectable()
export class UpsellConfig implements Configuration {}
