import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Submittable} from '@otter/common';
import {Configurable} from '@otter/core';
import {CartService} from '@otter/services';
import {combineLatest} from 'rxjs/observable/combineLatest';
import {filter, take} from 'rxjs/operators';

import {Subscription} from 'rxjs/Subscription';

import {TravelerConfig} from './traveler.config';

@Component({
  selector: 'o3r-traveler',
  styleUrls: ['./traveler.style.scss'],
  templateUrl: './traveler.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TravelerComponent implements OnInit, OnDestroy, Configurable<TravelerConfig> {
  /**
   * Configuration of the component
   * @Input
   */
  @Input() public config: TravelerConfig;

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  constructor(config: TravelerConfig, private router: Router, public cartService: CartService) {
    this.config = config;
  }

  ngOnInit() {
    // Run on component initialization
  }

  goBack() {
    // No logic yet
    this.router.navigate(['/fare']);
  }

  goNext(submittables: Submittable[]) {
    // No logic yet
    // Travelers are added manually
    const submitables$ = submittables.map((submittable) => submittable.submit());
    combineLatest(submitables$).pipe(take(1), filter((results) => results.every((result) => !!result)));
    this.router.navigate(['/payment']);
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
