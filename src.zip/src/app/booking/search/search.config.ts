import {Injectable} from '@angular/core';
import {Configuration} from '@otter/core';

@Injectable()
export class SearchConfig implements Configuration {}
