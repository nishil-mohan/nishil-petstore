import {Injectable} from '@angular/core';
import {Configuration} from '@otter/core';

@Injectable()
export class CalendarConfig implements Configuration {}
