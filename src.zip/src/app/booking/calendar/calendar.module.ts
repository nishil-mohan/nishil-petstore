import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {CalendarPerBoundMonthContModule} from '@otter/components';

import {CalendarComponent} from './calendar.component';
import {CalendarConfig} from './calendar.config';

@NgModule({
  imports: [
    RouterModule.forChild([{path: '', component: CalendarComponent}]),
    CommonModule,

    // Calendar page components
    CalendarPerBoundMonthContModule
  ],
  declarations: [CalendarComponent],
  exports: [CalendarComponent],
  providers: [CalendarConfig]
})
export class CalendarModule {}
