# FareComponent

the fare review page
