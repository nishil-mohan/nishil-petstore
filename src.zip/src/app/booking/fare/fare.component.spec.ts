import {DebugElement} from '@angular/core';
import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {BrowserModule, By} from '@angular/platform-browser';
import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from '@angular/platform-browser-dynamic/testing';

import {FareComponent} from './fare.component';
import {FareConfig} from './fare.config';

TestBed.initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting());

let fixture: ComponentFixture<FareComponent>;

describe('FareComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FareComponent],
      imports: [BrowserModule],
      providers: [FareConfig]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FareComponent);
  });

  xit('Should display the component name in a span', () => {
    const titleDebugElement: DebugElement = fixture.debugElement.query(By.css('span'));
    expect(titleDebugElement.nativeElement.innerText).toBe('FareComponent, works!');
  });
});
