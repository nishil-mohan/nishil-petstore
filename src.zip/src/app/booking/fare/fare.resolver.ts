import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {StateStatus} from '@otter/core';
import {CartService} from '@otter/services';
import {Cart as CartStore} from '@otter/store';
import {Observable} from 'rxjs/Observable';
import {filter, first} from 'rxjs/operators';

@Injectable()
export class FareResolver implements Resolve<CartStore.Model | null> {
  constructor(private cartService: CartService) {}

  resolve(): Observable<CartStore.Model | null> {
    return this.cartService.cart$.pipe(filter((cartState) => !!cartState && cartState.stateStatus !== StateStatus.loading), first());
  }
}
