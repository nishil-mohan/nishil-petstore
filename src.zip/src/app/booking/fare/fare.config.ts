import {Injectable} from '@angular/core';
import {Configuration} from '@otter/core';

@Injectable()
export class FareConfig implements Configuration {}
