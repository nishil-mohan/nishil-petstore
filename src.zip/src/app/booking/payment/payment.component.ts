import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Configurable} from '@otter/core';
import {OrderService} from '@otter/services';

import {filter, skip, take} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';

import {Submittable} from '@otter/common';
import {combineLatest} from 'rxjs/observable/combineLatest';
import {PaymentConfig} from './payment.config';

@Component({
  selector: 'o3r-payment',
  styleUrls: ['./payment.style.scss'],
  templateUrl: './payment.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentComponent implements OnInit, OnDestroy, Configurable<PaymentConfig> {
  /**
   * Configuration of the component
   * @Input
   */
  @Input() public config: PaymentConfig;

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  constructor(config: PaymentConfig, private orderService: OrderService, private router: Router) {
    this.config = config;
  }

  ngOnInit() {
    this.subscriptions.push(
      this.orderService.orderRequest$.pipe(filter((state) => !!state && !!state.paymentMethod)).subscribe(() => {
        this.orderService.checkout();
      })
    );

    this.subscriptions.push(this.orderService.checkoutState$.pipe(skip(1)).subscribe(() => this.router.navigate(['/reservation'])));
  }

  goBack() {
    // No logic yet
    this.router.navigate(['/traveler']);
  }

  goNext(submittables: Submittable[]) {
    // No logic yet
    const submitables$ = submittables.map((submittable) => submittable.submit());
    combineLatest(submitables$).pipe(take(1), filter((results) => results.every((result) => !!result)));
    this.router.navigate(['/reservation']);
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
