import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, Resolve, Router, RouterStateSnapshot} from '@angular/router';

@Injectable()
export class PaymentResolver implements Resolve<any> {
  resolve(route: ActivatedRouteSnapshot) {
    return route.queryParams;
  }
}
