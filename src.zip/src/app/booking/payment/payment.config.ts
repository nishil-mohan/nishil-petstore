import {Injectable} from '@angular/core';
import {Configuration} from '@otter/core';

@Injectable()
export class PaymentConfig implements Configuration {}
