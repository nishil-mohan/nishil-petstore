import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {CreditCardFormContModule} from '@otter/components';

import {PaymentComponent} from './payment.component';
import {PaymentConfig} from './payment.config';

@NgModule({
  imports: [RouterModule.forChild([{path: '', component: PaymentComponent}]), CommonModule, CreditCardFormContModule],
  declarations: [PaymentComponent],
  exports: [PaymentComponent],
  providers: [PaymentConfig]
})
export class PaymentModule {}
