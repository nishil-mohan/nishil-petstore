import {Injectable} from '@angular/core';
import {Resolve} from '@angular/router';
import {StateStatus} from '@otter/core';
import {OrderService} from '@otter/services';
import {Checkout as CheckoutStore} from '@otter/store';
import {Observable} from 'rxjs/Observable';
import {filter, first} from 'rxjs/operators';

@Injectable()
export class ReservationResolver implements Resolve<CheckoutStore.State> {
  constructor(private orderService: OrderService) {}

  resolve(): Observable<CheckoutStore.State> {
    return this.orderService.checkoutState$.pipe(filter((orderState) => !!orderState && orderState.stateStatus !== StateStatus.loading), first());
  }
}
