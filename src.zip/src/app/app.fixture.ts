import {O3rComponentFixture} from '@otter/common/dist/testing/core';
import {SimpleHeaderPresComponentFixture} from '@otter/components/dist/fixtures';
import {FareFixture, SearchFixture, UpsellFixture} from '../fixtures';

export class AppFixture extends O3rComponentFixture {
  /* selectors */
  protected readonly HEADER = '#header';
  protected readonly MESSAGE_LIST = '#message-list';
  protected readonly SEARCH_PAGE = '#search';
  protected readonly UPSELL_PAGE = '#upsell';
  protected readonly FARE_PAGE = '#fare';

  /**
   * Returns the header fixture
   */
  async getHeader() {
    return new SimpleHeaderPresComponentFixture(this.throwOnUndefined(await this.query(this.HEADER)));
  }

  /**
   * Returns the message list fixture
   */
  async getMessagesList() {
    throw new Error('Not implemented yet');
  }

  /**
   * Get the search page fixture
   */
  async getSearchPage() {
    const search = await this.query(this.SEARCH_PAGE);
    return search && new SearchFixture(search);
  }

  /**
   * Get the upsell page fixture
   */
  async getUpsellPage() {
    const upsell = await this.query(this.UPSELL_PAGE);
    return upsell && new UpsellFixture(upsell);
  }

  /**
   * Get the fare page fixture
   */
  async getFarePage() {
    const fare = await this.query(this.FARE_PAGE);
    return fare && new FareFixture(fare);
  }
}
