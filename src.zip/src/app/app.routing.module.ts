import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

const appRoutes: Routes = [
  {
    path: '',
    children: [
      {path: '', redirectTo: '/search', pathMatch: 'full'},
      {path: 'navToCart', redirectTo: '/shopping/wewewe', pathMatch: 'full'},
      {path: 'search', loadChildren: './booking/search/index#SearchModule'},
      {path: 'calendar', loadChildren: './booking/calendar/index#CalendarModule'},
      {path: 'upsell', loadChildren: './booking/upsell/index#UpsellModule'},
      {path: 'fare', loadChildren: './booking/fare/index#FareModule'},
      {path: 'traveler', loadChildren: './booking/traveler/index#TravelerModule'},
      {path: 'payment', loadChildren: './booking/payment/index#PaymentModule'},
      {path: 'shopping/:id', loadChildren: './booking/supercart/index#SuperCartModule'},
      {path: 'reservation', loadChildren: './booking/reservation/index#ReservationModule'}
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule {}
