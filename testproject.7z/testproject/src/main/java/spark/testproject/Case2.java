package spark.testproject;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class Case2 {

	public static void main(String s[]) {
		
		SparkConf conf=new SparkConf().setAppName("Demo").setMaster("local[*]");
		JavaSparkContext context=new JavaSparkContext(conf);
		JavaRDD<String> data = context.textFile(s[0]);
		
		JavaRDD<String> rdd_records = data.filter(line->
				  {
				         String[] fields = line.split(",");
				         if(fields.length>4 && fields[5].equals("4")) {
				        	 return true;
				         }
				         return false;
				      }
				);
		rdd_records.saveAsTextFile(s[1]);
		context.close();
	}
}
