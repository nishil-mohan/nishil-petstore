package spark.testproject;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

public class Case3 {

	public static void main(String s[]) {
		
		SparkConf conf=new SparkConf().setAppName("Demo").setMaster("local[*]");
		JavaSparkContext context=new JavaSparkContext(conf);
		JavaRDD<String> data = context.textFile(s[0]);
		String header = data.first() ;
		data = data.filter(row -> !row.equals(header) && row.trim().length()>0);
		
		JavaPairRDD<String,Integer> flattenPairs =
				data.mapToPair(line ->{
					 String paymentType=line.split(",")[9];
					 return new Tuple2<String,Integer>(paymentType,1);
				});
		
		JavaPairRDD<String, Integer> wordCountRDD = flattenPairs.reduceByKey((v1,v2) -> v1+v2);
		
		JavaPairRDD<Integer, String> wordCountRDDReversed=wordCountRDD.mapToPair(x->new Tuple2<Integer,String>(x._2, x._1));
		wordCountRDDReversed.sortByKey().saveAsTextFile(s[1]);
		/*//System.out.println(stats_records.count());
		List<Tuple2<String, Integer>> result=wordCountRDD.collect();
		List<Tuple2<String, Integer>> modifiableResult=new ArrayList<Tuple2<String, Integer>>(result);
		modifiableResult.sort((x,y)->y._2().compareTo(x._2()));
		List<String> fileOutput=new ArrayList<>();
		for(Tuple2<String, Integer> res:modifiableResult) {
			fileOutput.add(res._1()+"--"+res._2());
		}
		try {
			Files.write(Paths.get(s[1]), fileOutput);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		context.close();
	}
}
