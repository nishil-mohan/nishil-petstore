package spark.testproject; 

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;


public class Case1 {

	public static void main(String s[]) {
		
		SparkConf conf=new SparkConf().setAppName("Demo").setMaster("local[*]");
		JavaSparkContext context=new JavaSparkContext(conf);
		JavaRDD<String> data = context.textFile(s[0]);
		
		JavaRDD<String> rdd_records = data.filter(line->
				  {
				         String[] fields = line.split(",");
				         if(fields.length>4 && fields[0].equals("2") && fields[2].equals("2017-10-01 00:25:11") &&
				fields[1].equals("2017-10-01 00:15:30") && fields[3].equals("1") && 
				fields[4].equals("2.17")) {
				        	 return true;
				         }
				         return false; 
				      }
				);
		rdd_records.saveAsTextFile(s[1]);;
		 
		context.close();
	}
}
