# Otter Demo App
Demo App using Otter libraries

## Build and run
```bash
yarn install
yarn start
```