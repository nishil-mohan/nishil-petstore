import {initFetchManager, stopFetchManager} from '@otter/common/dist/testing/tools/protractor';
import * as fs from 'fs';
import * as path from 'path';
import {browser} from 'protractor';

/**
 * Interface to define the interface of a flow test
 */
export interface Flow {
  /**
   * Run the flow
   */
  performFlow(): void;
}

/**
 * Base scenario for e2e scenarios.
 * Init the fetch manager and call `performFlow` method.
 * E2E Booking flows should inherit from this class.
 */
export abstract class BaseScenario implements Flow {
  abstract performFlow();

  run() {
    describe(this.constructor.name, () => {
      beforeAll(async () => {
        // open the url
        await browser.get(browser.baseUrl);
        await browser.driver.manage().deleteAllCookies();
        // inject the fetch manager in the browser
        await initFetchManager();
      });

      afterAll(async () => {
        // stop the fetch manager
        await stopFetchManager();
      });

      this.performFlow();
    });
  }
}
