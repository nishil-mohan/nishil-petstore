import {IFareInfo, IPassenger} from '@otter/components/dist/blocks/fixtures';
import {AppFixture} from '../../src/app/app.fixture';

/**
 * Shortcut to search a flight
 * This method manages only simple cases and will throw if any unexpected behaviour is triggered.
 *
 * @param oneWay If true, one way, if false round-trip
 * @param flexible If true, +-3days, if false no flexible dates
 * @param departureDate Date of departure
 * @param departureCode IATA code of departure airport
 * @param arrivalCode IATA code of departure airport
 * @param nbAdults Number of adults
 * @param nbChildren Number of children
 * @param nbInfants Number of infants
 */
export async function searchFlight(
  oneWay: boolean,
  flexible: boolean,
  nbAdults: number,
  nbChildren: number,
  nbInfants: number,
  departureCode: string,
  departureDate: Date,
  arrivalCode: string,
  arrivalDate?: Date
) {
  const app = new AppFixture();
  const searchFixture = await (await app.getSearchPage()).getAirSearch();

  if (oneWay) {
    await searchFixture.selectOneWay();
  } else {
    await searchFixture.selectRoundTrip();
  }

  await searchFixture.setLocationValue(0, departureCode);
  // TODO Uncomment this line when DPUI-327 is fixed
  // await searchFixture.setDateValue(0, departureDate.toUTCString());
  console.warn('Departure date could not be set until DPUI-327 is fixed.');

  await searchFixture.setLocationValue(1, arrivalCode);
  if (!oneWay) {
    // TODO Uncomment this line when DPUI-327 is fixed
    // await searchFixture.setDateValue(1, arrivalDate.toUTCString());
    throw new Error('Round-trip flow could not be run until DPUI-327 is fixed.');
  }

  const pax: IPassenger[] = [];
  pax.push({passengerNumber: nbAdults, passengerType: 'ADT'});
  pax.push({passengerNumber: nbChildren, passengerType: 'CHD'});
  pax.push({passengerNumber: nbInfants, passengerType: 'INF'});
  await searchFixture.setPassengers(pax);

  return searchFixture.search();
}

/**
 * Information of the selected offers
 */
export interface UpsellInfos {
  totalPrice: number;
}

/**
 * Shortcut to select the lowest fare for each bound
 */
export async function selectLowestFares() {
  const app = new AppFixture();
  const upsell = await app.getUpsellPage();
  const nbBounds = await upsell.getNbBounds();

  const infos: IFareInfo[] = [];

  for (let boundIndex = 0; boundIndex < nbBounds; boundIndex++) {
    const upsellBound = await upsell.getUpsellBound(boundIndex);
    infos.push(await upsellBound.selectFirstLowestFareCell());
  }

  await upsell.validate();
  return infos;
}

/**
 * Pass the fare page
 */
export async function validateFare() {
  const app = new AppFixture();
  const fare = await app.getFarePage();
  return fare.validate();
}
