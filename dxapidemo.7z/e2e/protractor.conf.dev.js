'use strict';

const failFast = require('protractor-fail-fast');
const JasmineSpecReporter = require('jasmine-spec-reporter').SpecReporter;
const JasmineJsonReporter = require('@otter/shell/testing/e2e/dist').JsonReporter;
const Jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');
const defaultProtractorConfig = require('@otter/shell/testing/e2e/config/protractor.e2e.js');

module.exports = (options) => {
  const config = {
    jasmineNodeOpts: {
      includeStackTrace: true
    },
    plugins: [failFast.init()],
    afterLaunch: () => {
      failFast.clean();
    },
    directConnect: true,
    onPrepare: () => {
      browser.ignoreSynchronization = false;
      browser
        .manage()
        .window()
        .maximize();
      browser
        .manage()
        .timeouts()
        .setScriptTimeout(60000);
      jasmine.getEnv().addReporter(
        new JasmineSpecReporter({
          suite: {
            displayNumber: true
          },
          spec: {
            displaySuccessful: true
          },
          summary: {
            displaySuccessful: true
          }
        })
      );
      jasmine.getEnv().addReporter(
        new Jasmine2HtmlReporter({
          savePath: 'dist-e2e-reports/html/',
          takeScreenshotsOnlyOnFailures: true,
          cleanDestination: false,
          fileNameDateSuffix: true
        })
      );
      jasmine.getEnv().addReporter(
        new JasmineJsonReporter({
          outputFolder: 'dist-e2e-reports/json/'
        })
      );
    },
    capabilities: {
      browserName: 'chrome'
    }
  };

  return Object.assign(defaultProtractorConfig(options), config);
};
