# Protractor E2E testing for o3r-demo-app

## Run e2e tests in local

```shell
npm run e2e:run
```

