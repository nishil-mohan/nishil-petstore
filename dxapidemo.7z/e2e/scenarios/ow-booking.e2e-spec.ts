import {waitForOtterStable} from '@otter/common/dist/testing/tools/protractor';
import {AirSearchFixture} from '@otter/components/dist/blocks/fixtures';
import {browser, By, element, ElementFinder, ExpectedConditions} from 'protractor';
import {AppFixture, UpsellFixture} from '../../src/fixtures';
import {BaseScenario, Flow, searchFlight, validateFare} from '../utils';

/**
 * One way flow from NCE to HEL
 * 2 ADT, 2 CHD
 */
export class OWBooking extends BaseScenario {
  readonly DEPARTURE_CITY_CODE = 'NCE';
  readonly ARRIVAL_CITY_CODE = 'HEL';
  readonly NB_ADT = 2;
  readonly NB_CHD = 2;
  readonly NB_INF = 0;
  readonly DEPARTURE_DATE: Date;

  constructor() {
    super();

    // departure is in 5 days
    const date = new Date();
    date.setDate(date.getDate() + 5);
    this.DEPARTURE_DATE = date;
  }

  /**
   * Search for a flight without testing search page
   */
  protected search() {
    describe('search page', () => {
      beforeAll(async () => {
        await waitForOtterStable();
      });
      it('should search for one way flight', async () => {
        await searchFlight(true, false, this.NB_ADT, this.NB_CHD, this.NB_INF, this.DEPARTURE_CITY_CODE, this.DEPARTURE_DATE, this.ARRIVAL_CITY_CODE);
      });
    });
  }

  /**
   * Select an offer on the next date available
   */
  protected upsell() {
    describe('upsell page', () => {
      let app: AppFixture;
      let upsell: UpsellFixture;

      beforeAll(async () => {
        await waitForOtterStable();
        app = new AppFixture();
        upsell = await app.getUpsellPage();
      });

      it('should be on upsell page', () => {
        expect(upsell).toBeDefined();
      });

      it('should have one bound', async () => {
        expect(await upsell.getNbBounds()).toEqual(1);
      });

      it('should be consistent with search criterias', async () => {
        expect(await upsell.getOriginLocationCode(0)).toEqual(this.DEPARTURE_CITY_CODE);
        expect(await upsell.getArrivalLocationCode(0)).toEqual(this.ARRIVAL_CITY_CODE);
      });

      it('shound have a calendar per bound', async () => {
        expect(await upsell.getCalendar(0)).toBeDefined();
      });

      it('should have an upsell', async () => {
        expect(await upsell.getUpsellBound(0)).toBeDefined();
      });

      it('should select the next date available in the calendar', async () => {
        await (await upsell.getCalendar(0)).clickNextDateAvailable();
      });

      it('should display offers', async () => {
        const upsellComponent = await upsell.getUpsellBound(0);
        expect(upsellComponent).toBeDefined();
        expect(await upsellComponent.getNbFlights()).toBeGreaterThan(0);
      });

      it('should select the first offer', async () => {
        await (await upsell.getUpsellBound(0)).selectFirstAvailableCell();
      });

      it('should validate the selection and change the page', async () => {
        await upsell.validate();
      });
    });
  }

  protected fare() {
    describe('fare page', () => {
      beforeAll(async () => {
        await waitForOtterStable();
      });
      it('should continue', async () => {
        await validateFare();
      });
    });
  }

  performFlow() {
    this.search();
    this.upsell();
    this.fare();
  }
}
new OWBooking().run();
