import {waitForOtterStable} from '@otter/common/dist/testing/tools/protractor';
import {AppFixture} from '../../src/fixtures';
import {BaseScenario, Flow, searchFlight, selectLowestFares, validateFare} from '../utils';

/**
 * Simple one way booking flow using prefill methods
 */
export class SimpleOWBooking extends BaseScenario {
  readonly DEPARTURE_CITY_CODE = 'NCE';
  readonly ARRIVAL_CITY_CODE = 'HEL';
  readonly NB_ADT = 2;
  readonly NB_CHD = 2;
  readonly NB_INF = 0;
  readonly DEPARTURE_DATE: Date;

  constructor() {
    super();

    // departure is in 5 days
    const date = new Date();
    date.setDate(date.getDate() + 5);
    this.DEPARTURE_DATE = date;
  }

  /**
   * Search for a flight without testing search page
   */
  protected search() {
    describe('search page', () => {
      beforeAll(async () => {
        await waitForOtterStable();
      });
      it('should search for flight', async () => {
        await searchFlight(true, false, this.NB_ADT, this.NB_CHD, this.NB_INF, this.DEPARTURE_CITY_CODE, this.DEPARTURE_DATE, this.ARRIVAL_CITY_CODE);
      });
    });
  }

  /**
   * Select lowest fare without testing the page
   */
  protected upsell() {
    describe('upsell page', () => {
      beforeAll(async () => {
        await waitForOtterStable();
      });
      it('should select lowest offer', async () => {
        await selectLowestFares();
      });
    });
  }

  /**
   * Pass the fare page
   */
  protected fare() {
    describe('fare page', () => {
      beforeAll(async () => {
        await waitForOtterStable();
      });
      it('should continue', async () => {
        await validateFare();
      });
    });
  }

  performFlow() {
    this.search();
    this.upsell();
    this.fare();
  }
}
new SimpleOWBooking().run();
