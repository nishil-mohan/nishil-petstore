import {FactoryProvider, InjectionToken, Optional} from '@angular/core';
import {Store} from '@ngrx/store';

import {StoreStates} from '@otter/store';
import {AirSearchCriteria} from '../../../store/air';
import {AirSearchCriteriaService} from './air-search-criteria.service';

export function createAirSearchCriteriaService(customService: AirSearchCriteriaService, store: Store<AirSearchCriteriaServiceState>) {
  return customService ? customService : new AirSearchCriteriaService(store);
}

/**
 * State of the store
 */
export interface AirSearchCriteriaServiceState extends StoreStates {
  airSearchCriteria: AirSearchCriteria.State;
}

/**
 * Token to be provided in case of service customization needs.
 */
export const AIR_SEARCH_CRITERIA_CUSTOM_SERVICE_TOKEN = new InjectionToken<AirSearchCriteriaServiceState>('AirSearchCriteriaService injection token');

/**
 * AirSearchCriteriaService provider
 */
export const airSearchCriteriaServiceProvider: FactoryProvider = {
  provide: AirSearchCriteriaService,
  useFactory: createAirSearchCriteriaService,
  deps: [[new Optional(), AIR_SEARCH_CRITERIA_CUSTOM_SERVICE_TOKEN], Store]
};
