import {ModuleWithProviders, NgModule} from '@angular/core';
import {AirSearchCriteriaModule as AirSearchCriteriaStoreModule} from '../../../store/air';

import {AIR_SEARCH_CRITERIA_CUSTOM_SERVICE_TOKEN, airSearchCriteriaServiceProvider} from './air-search-criteria.providers';

export * from './air-search-criteria.service';
export * from './air-search-criteria.providers';

export interface CustomAirSearchCriteria {
  airSearchCriteriaService?: any;
}

/**
 * AirSearchCriteriaService Module
 */
@NgModule({imports: [AirSearchCriteriaStoreModule], providers: [airSearchCriteriaServiceProvider]})
export class AirSearchCriteriaModule {
  public static forRoot(services: CustomAirSearchCriteria): ModuleWithProviders {
    const providers = [];
    if (services.airSearchCriteriaService) {
      providers.push({provide: AIR_SEARCH_CRITERIA_CUSTOM_SERVICE_TOKEN, useClass: services.airSearchCriteriaService});
    }
    return {ngModule: AirSearchCriteriaModule, providers: providers};
  }
}
