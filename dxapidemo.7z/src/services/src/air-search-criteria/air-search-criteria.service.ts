import {Injectable} from '@angular/core';
import {AirSearchCriteria} from '@dapi/sdk/models';
import {select, Store} from '@ngrx/store';
import {Observable} from 'rxjs/Observable';
import {distinctUntilChanged, map, shareReplay} from 'rxjs/operators';
import {AirSearchCriteriaServiceState} from '../../../services/src/air-search-criteria/air-search-criteria.providers';
import {AirSearchCriteria as AirSearchCriteriaStore} from '../../../store/air';

/**
 * AirSearchCriteria service
 * Search criteria service module
 */
@Injectable()
export class AirSearchCriteriaService {
  /**
   * Observable of the SearchCriteria
   */
  public searchCriteria$: Observable<AirSearchCriteriaStore.Model | null>;
  public activeSearchCriteriaIds$: Observable<string[]>;
  public activeSearchCriterias$: Observable<AirSearchCriteriaStore.Model[] | null>;

  /**
   * Observable of the SearchCriteria instance
   */
  public searchCriteriaInstance$: Observable<AirSearchCriteria | undefined>;

  constructor(public store: Store<AirSearchCriteriaServiceState>) {
    this.searchCriteria$ = store.pipe(select(AirSearchCriteriaStore.selectCurrentAirSearchCriteria));
    this.activeSearchCriteriaIds$ = store.pipe(select(AirSearchCriteriaStore.selectActiveSearchCriteriaIds));
    this.activeSearchCriterias$ = store.pipe(select(AirSearchCriteriaStore.selectActiveSearchCriterias));

    this.searchCriteriaInstance$ = this.searchCriteria$.pipe(
      map((searchCriteria) => (!!searchCriteria ? searchCriteria : undefined)),
      distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b)),
      shareReplay(1)
    );
  }

  /**
   * Update specific SearchCriteria into the store
   * @param search
   */
  public updateSearchCriteria(search: AirSearchCriteria) {
    this.store.dispatch(new AirSearchCriteriaStore.Actions.AddAndSelect(search));
  }

  /**
   * Clear the current criteria presents in the store.
   */
  public clearSearchCriteria() {
    this.store.dispatch(new AirSearchCriteriaStore.Actions.ClearAll());
  }

  /**
   * Add search criteria
   * @param {AirSearchCriteria} search
   */
  public addSearchCriteria(search: AirSearchCriteria) {
    this.store.dispatch(new AirSearchCriteriaStore.Actions.Add(search));
  }

  /**
   * Select search criteria
   * @param {AirSearchCriteria} search
   */
  public selectSearchCriteria(search: AirSearchCriteria) {
    this.store.dispatch(new AirSearchCriteriaStore.Actions.Select({id: AirSearchCriteriaStore.generateSearchCrc(search)}));
  }

  /**
   * Select search criteria
   * @param {AirSearchCriteria} search
   */
  public selectSearchCriteriaById(id: string) {
    this.store.dispatch(new AirSearchCriteriaStore.Actions.Select({id: id}));
  }

  /**
   * Select search criteria
   * @param {AirSearchCriteria} search
   */
  public addSearchCriterias(airSearchCriterias: AirSearchCriteria[]) {
    airSearchCriterias.forEach((airSearchCriteria) => {
      this.store.dispatch(new AirSearchCriteriaStore.Actions.AddAndActive(airSearchCriteria));
    });
  }
}
