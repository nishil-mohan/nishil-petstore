import {Injectable, Optional} from '@angular/core';
import {utils} from '@dapi/sdk-core/fwk';
import {AirOfferApi} from '@dapi/sdk/api';
import {buildKeyFromSelection, createUpsell, getTotalAmounts, updateFlightFares} from '@dapi/sdk/helpers';
import {AirOffer, AirSearchCriteria, Amount, FlightSelection, reviveAirSearchCriteria, Upsell, UpsellFlightFare} from '@dapi/sdk/models';
import {select, Store} from '@ngrx/store';
import {StateStatus} from '@otter/core';
import {AirCalendarService, LoggerService} from '@otter/services';
import {SelectedEntry} from '@otter/store';
import {Observable} from 'rxjs/Observable';
import {combineLatest, filter, map, shareReplay, take, tap, withLatestFrom} from 'rxjs/operators';
import {AirOffers, AirSearchCriteria as AirSearchCriteriaStore} from '../../../store/air';
import {Model} from '../../../store/air/air-offers';
import {AirOfferServiceState} from './air-offer.providers';

/**
 * AirOffer service
 */
@Injectable()
export class AirOfferService {
  /**
   * AirOffer API
   */
  protected api: AirOfferApi;

  /**
   * Observable of searchCriteria
   */
  protected searchCriteria$: Observable<AirSearchCriteria | undefined | null>;

  public lowestPricePerSearchCriteria: ({amount: Amount; value: number} | undefined)[] = [];

  /**
   * Observable of searchCriteria
   */
  // protected searchCriterias$: Observable<AirSearchCriteria[] | undefined | null>;
  public offers: {[key: string]: Model} = {};

  /**
   * Observable of the selected Offer
   */
  public viewedOffer$: Observable<AirOffer | null>;

  /**
   * Observable of the selected offer entries
   */
  public selectedEntries$: Observable<SelectedEntry.State>;

  /**
   * Observable of the selected offer entries
   */
  public selectedEntriesByIndex$: Observable<FlightSelection[]>;

  /**
   * Observable of the list of AirOffers
   */
  public offers$: Observable<AirOffers.Model[]>;

  /**
   * Observable of the list of AirOffers
   */
  public test$: Observable<({amount: Amount; value: number} | undefined)[]>;

  /**
   * Observable to get the state status block
   */
  public offersState$: Observable<AirOffers.State>;

  /**
   * Subject that can be subscribed on to get an Upsell pojo object with the current AirOffers
   */
  public upsell$: Observable<Upsell>;

  /**
   * Observable of searchCriteria with calendar selected dates
   */
  public ajustedSearchCriterias$: Observable<(AirSearchCriteria | undefined)[] | null | undefined>;

  constructor(api: AirOfferApi, public store: Store<AirOfferServiceState>, private logger: LoggerService, @Optional() private airCalendarService: AirCalendarService) {
    this.api = api;
    this.offersState$ = store.pipe(select(AirOffers.selectAirOffersState));
    const offers$ = store.pipe(select(AirOffers.selectAllAirOffers));
    this.selectedEntries$ = store.pipe(select(SelectedEntry.selectSelectedEntryState));
    this.selectedEntriesByIndex$ = this.selectedEntries$.pipe(
      filter((selectedEntriesState) => !!selectedEntriesState),
      map((selectedEntries) => [0, 1].map((boundType) => selectedEntries[boundType]))
    );

    this.searchCriteria$ = this.airCalendarService ? this.airCalendarService.ajustedSearchCriteria$ : store.pipe(select(AirSearchCriteriaStore.selectCurrentAirSearchCriteria));
    // this.searchCriterias$ = this.airCalendarService ? this.airCalendarService.ajustedSearchCriteria$ : store.pipe(select(AirSearchCriteriaStore.selectActiveSearchCriterias));
    // TODO prevent refresh
    // this.searchCriteriaInstance$ = store.pipe(
    //     select(AirSearchCriteriaStore.selectCurrentAirSearchCriteria),
    //     distinctUntilChanged(
    //         (criteriaA: AirSearchCriteriaStore.Model, criteriaB: AirSearchCriteriaStore.Model) => !!(criteriaA && criteriaB) && (criteriaA.id === criteriaB.id)
    //     )
    // );
    if (this.airCalendarService) {
      this.ajustedSearchCriterias$ = store.pipe(select(AirSearchCriteriaStore.selectActiveSearchCriterias)).pipe(
        combineLatest(this.airCalendarService.selectedDates$),
        map(([searchCriteriasState, calendarSelectedDates]) => {
          return searchCriteriasState.map((searchCriteriaState) => {
            const searchCriteria = reviveAirSearchCriteria(searchCriteriaState);
            if (calendarSelectedDates && searchCriteria && searchCriteria.bounds.length) {
              calendarSelectedDates.forEach((calendarSelectedDate, idx) => {
                if (searchCriteria.bounds[idx]) {
                  searchCriteria.bounds[idx].departureDateTime = new utils.DateTime(calendarSelectedDate);
                }
              });
            }
            return searchCriteria;
          });
        }),
        shareReplay(1)
      );
    }
    // return the offers and trigger a loadOffers on searchCriteria changes
    this.offers$ = this.searchCriteria$.pipe(
      tap((searchCriteria) => {
        if (searchCriteria) {
          this.loadOffers(searchCriteria);
        }
      }),
      combineLatest(offers$, (_searchCriteria, offers) => offers),
      shareReplay(1)
    );
    this.test$ = this.offers$.pipe(
      withLatestFrom(
        store.pipe(select(AirSearchCriteriaStore.selectActiveSearchCriterias)),
        store.pipe(select(AirSearchCriteriaStore.selectActiveSearchCriteriaIds)),
        (offers, airSearchCriterias, airSearchCriteriasIds) => {
          // if (airSearchCriterias) {
          const lowestPricePerSearchCriteria: ({amount: Amount; value: number} | undefined)[] = [];
          airSearchCriteriasIds.forEach((airSearchCriteriaId, index: number) => {
            lowestPricePerSearchCriteria[index] = this.getLowerPriceForCriteria(airSearchCriteriaId, offers);
          });
          return lowestPricePerSearchCriteria;
        }
      ),
      shareReplay(1)
    );
    // Create and update Upsell pojo when getting new offers
    const upsell$ = this.offers$.pipe(
      withLatestFrom(store.pipe(select(AirOffers.selectAirOffersState))),
      filter(([offers, offersState]) => offersState.stateStatus === StateStatus.ready && !!offers && !!offers.length),
      map(([offers]) => createUpsell(offers))
    );

    // Update Upsell pojo when getting new selection
    this.upsell$ = upsell$.pipe(
      combineLatest(this.selectedEntries$),
      tap(([upsell, selectedEntries]) => {
        updateFlightFares(upsell, [selectedEntries[0], selectedEntries[1]]);

        let viewedOffer: AirOffer | undefined;
        if (upsell.bounds.length > 1) {
          if (selectedEntries[0] && selectedEntries[1]) {
            viewedOffer = upsell.airOffers[buildKeyFromSelection(selectedEntries[0]) + '_' + buildKeyFromSelection(selectedEntries[1])];
          }
        } else {
          viewedOffer = selectedEntries[0] && upsell.airOffers[buildKeyFromSelection(selectedEntries[0])];
        }

        if (viewedOffer) {
          this.viewOffer(viewedOffer);
        }
      }),
      map(([upsell]) => upsell),
      shareReplay(1)
    );

    this.viewedOffer$ = store.pipe(select(AirOffers.selectCurrentAirOffer)).pipe(shareReplay(1));
  }

  public clearOffer() {
    this.store.dispatch(new AirOffers.Actions.ClearAll());
  }

  /**
   * Select a specific Offer
   */
  public viewOffer(offer: AirOffer) {
    this.store.dispatch(new AirOffers.Actions.SelectOffer(offer));
  }

  public selectEntry(boundIndex: number, flightId: string, fareFamilyCode: string) {
    const action = boundIndex ? SelectedEntry.Actions.SetInbound : SelectedEntry.Actions.SetOutbound;
    this.store.dispatch(new action({flightId: flightId, fareFamilyCode: fareFamilyCode}));
  }

  public selectFlightFare(boundIndex: number, flightFare: UpsellFlightFare) {
    if (flightFare.flight && flightFare.flight.fareFamilyCode) {
      if (flightFare.isNotCombinable) {
        this.clearEntry(1 - boundIndex);
      }
      this.selectEntry(boundIndex, flightFare.flight.id!, flightFare.flight.fareFamilyCode);
    }
  }

  public clearEntry(boundIndex: number) {
    const action = boundIndex ? SelectedEntry.Actions.ClearInbound : SelectedEntry.Actions.ClearOutbound;
    this.store.dispatch(new action());
  }

  public deleteViewOffer(): void {
    this.store.dispatch(new AirOffers.Actions.ClearSelectedOffer());
  }

  /**
   * Retrieve a specific Offer
   */
  public retrieveOffer(offer: AirOffer) {
    const id = offer.id;
    this.store.dispatch(new AirOffers.Actions.RetrieveOffer(this.api.retrieveAirOffer({airOfferId: id}), {id}));
  }

  /**
   * Load offer list from search criteria
   */
  public loadOfferFromSearch() {
    this.searchCriteria$
      .pipe(
        take(1),
        filter((searchCriteria) => !!searchCriteria)
      )
      .subscribe((searchCriteria) => searchCriteria && this.loadOffers(searchCriteria));
  }

  /**
   * Basic Offer request
   * @param departureDateTime       Departure date
   * @param originLocationCode      Origin Location Code
   * @param destinationLocationCode Destination Location Code
   */
  public loadBasicOffers(departureDateTime: utils.DateTime, originLocationCode: string, destinationLocationCode: string) {
    this.store.dispatch(
      new AirOffers.Actions.Load(
        this.api.airShopping({
          departureDateTime: departureDateTime,
          originLocationCode: originLocationCode,
          destinationLocationCode: destinationLocationCode,
          commercialFareFamilies: ['-ALL-']
        }),
        ''
      )
    );
  }

  public loadOffers(searchCriteria: any) {
    const bound = searchCriteria.bounds[0];
    const returnBound = searchCriteria.bounds[1];
    if (!bound || !bound.departureDateTime || !bound.originLocationCode || !bound.destinationLocationCode) {
      return this.logger.error('invalid outbound data');
    }

    this.store.dispatch(
      // TODO Not implemented yet: searchCriteria.cabin
      new AirOffers.Actions.Load(
        this.api.airShopping({
          departureDateTime: bound.departureDateTime,
          originLocationCode: bound.originLocationCode,
          destinationLocationCode: bound.destinationLocationCode,
          returnDateTime: returnBound && returnBound.departureDateTime,
          commercialFareFamilies: searchCriteria.commercialFareFamilies || [],
          travelers: searchCriteria.travelers,
          departureTimeWindow: bound.timeWindow,
          returnTimeWindow: returnBound && returnBound.timeWindow,
          languageCode: searchCriteria.languageCode
        }),
        searchCriteria.id
      )
    );
  }

  public getLowerPriceForCriteria(airSearchCriteriaId: string, offers: Model[]): {amount: Amount; value: number} | undefined {
    const associatedOffers = Object.keys(offers)
      .filter((key) => offers[key].searchCriteriaId === airSearchCriteriaId)
      .map((key) => offers[key]);
    let lowestPrice: {amount: Amount; value: number} | undefined;
    if (associatedOffers.length > 0) {
      associatedOffers.forEach((offer) => {
        const amount: Amount = getTotalAmounts(offer)[0];
        if (!lowestPrice || parseFloat(amount.amount) < lowestPrice.value) {
          lowestPrice = {amount: amount, value: parseFloat(amount.amount)};
        }
      });
    }
    return lowestPrice;
  }
}
