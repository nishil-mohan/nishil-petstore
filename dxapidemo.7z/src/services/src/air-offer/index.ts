import {ModuleWithProviders, NgModule} from '@angular/core';
import {ApiManagerModule} from '@otter/common';
import {LoggerModule} from '@otter/services';
import {SelectedEntryModule as SelectedEntryStoreModule} from '@otter/store';
import {AirOffersModule as AirOffersStoreModule, AirSearchCriteriaModule as AirSearchCriteriaStoreModule} from '../../../store/air';
import {AIR_OFFER_CUSTOM_SERVICE_TOKEN, airOfferApiProvider, airOfferServiceProvider} from './air-offer.providers';

export * from './air-offer.service';
export * from './air-offer.providers';

export interface CustomAirOfferService {
  airOfferService?: any;
}

/**
 * AirOffer Module
 */
@NgModule({
  imports: [ApiManagerModule, AirOffersStoreModule, AirSearchCriteriaStoreModule, SelectedEntryStoreModule, LoggerModule],
  providers: [airOfferApiProvider, airOfferServiceProvider]
})
export class AirOfferModule {
  public static forRoot(services: CustomAirOfferService): ModuleWithProviders {
    const providers = [];
    if (services.airOfferService) {
      providers.push({provide: AIR_OFFER_CUSTOM_SERVICE_TOKEN, useClass: services.airOfferService});
    }
    return {ngModule: AirOfferModule, providers: providers};
  }
}
