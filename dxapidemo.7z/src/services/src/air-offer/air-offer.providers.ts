import {FactoryProvider, InjectionToken, Optional} from '@angular/core';
import {AirOfferApi} from '@dapi/sdk/api';
import {Store} from '@ngrx/store';
import {API_TOKEN} from '@otter/common';
import {ApiManager} from '@otter/core';
import {AirCalendarService, LoggerService} from '@otter/services';
import {SelectedEntry, StoreStates} from '@otter/store';
import {AirOffers, AirSearchCriteria} from '../../../store/air';

import {AirOfferService} from './air-offer.service';

export function createAirOfferApi(config: ApiManager): AirOfferApi {
  const apiConfig = config.getConfiguration(AirOfferApi.name);
  return new AirOfferApi(apiConfig.basePath, apiConfig.requestPlugins, apiConfig.replyPlugins);
}

export function createAirOfferService(
  customService: AirOfferService,
  airOfferApi: AirOfferApi,
  store: Store<AirOfferServiceState>,
  loggerService: LoggerService,
  airCalendarService: AirCalendarService
) {
  return customService ? customService : new AirOfferService(airOfferApi, store, loggerService, airCalendarService);
}

/**
 * Token to be provided in case of service customization needs.
 */
export const AIR_OFFER_CUSTOM_SERVICE_TOKEN = new InjectionToken<AirOfferServiceState>('AirOfferService injection token');

/**
 * AirOffer API providers
 */
export const airOfferApiProvider: FactoryProvider = {
  provide: AirOfferApi,
  useFactory: createAirOfferApi,
  deps: [API_TOKEN]
};

/**
 * State of the store
 */
export interface AirOfferServiceState extends StoreStates {
  airOffers: AirOffers.State;
  airSearchCriteria: AirSearchCriteria.State;
  selectedEntry: SelectedEntry.State;
}

/**
 * AirOfferService provider
 */
export const airOfferServiceProvider: FactoryProvider = {
  provide: AirOfferService,
  useFactory: createAirOfferService,
  deps: [[new Optional(), AIR_OFFER_CUSTOM_SERVICE_TOKEN], AirOfferApi, Store, LoggerService, [new Optional(), AirCalendarService]]
};
