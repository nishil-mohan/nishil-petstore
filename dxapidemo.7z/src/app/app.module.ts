import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule} from '@angular/router';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {EffectsModule} from '@ngrx/effects';
import {routerReducer, RouterStateSerializer, StoreRouterConnectingModule} from '@ngrx/router-store';
import {Action, ActionReducer, StoreModule} from '@ngrx/store';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import {TranslateModule} from '@ngx-translate/core';
import {ApiManagerModule, LocalizationModule, translateLoaderProvider} from '@otter/common';
import {FlightIdentifierModule, FooterPresModule, ListInlineMessagesContModule, SpinnerBooking3dModule} from '@otter/components';
import {ApiManager, config} from '@otter/core';
import {CartModule, OrderModule} from '@otter/services';
import {Cart as CartStore, Order, SelectedEntry, StoreReducers} from '@otter/store';
import {storeFreeze} from 'ngrx-store-freeze';
import {localStorageSync} from 'ngrx-store-localstorage';
import {AirSearchCriteriaModule} from '../services/src/air-search-criteria';

import {CustomSerializer} from '../debug';
import {analyticsMetaReducer} from '../services/analytics';
import {AppComponent} from './app.component';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {AirOfferModule, AirOfferService} from '../services/src/air-offer';
import {AirSearchCriteriaService} from '../services/src/air-search-criteria';
import {AirSearchCriteria} from '../store/air';
import {reducers} from '../store/shopping-basket/shopping-basket.state';
import {AppRoutingModule} from './app.routing.module';
import {SimpleHeaderPresModule} from './booking/simple-header';
import {createLocalizationConfiguration} from './configuration/localization';

const PROXY_SERVER = 'http://proxy.digitalforairlines.com/V1';

export function dapiFactory(): ApiManager {
  return new ApiManager({basePath: PROXY_SERVER});
}

export function localStorageSyncWrapper<T, V extends Action = Action>(reducer: ActionReducer<T, V>): ActionReducer<T, V> {
  // Store configuration
  const localStoragedStates = ['router', {airSearchCriteria: AirSearchCriteria.storageSync}, {order: Order.storageSync}, {selectedEntry: SelectedEntry.storageSync}, {cart: CartStore.storageSync}];
  return localStorageSync({keys: localStoragedStates, rehydrate: true})(reducer);
}

const rootReducers: StoreReducers = {
  router: routerReducer,
  cart: CartStore.reducer
};

const metaReducers = [...(config.DEBUG_MODE ? [storeFreeze] : []), ...(config.ENABLE_WEBSTORAGE ? [localStorageSyncWrapper] : []), analyticsMetaReducer];

@NgModule({
  imports: [
    ApiManagerModule.forRoot(dapiFactory),
    /**
     * you can also import LocalizationModule without calling its forRoot method
     * (you will be provided with some default LocalizationConfiguration)
     */
    LocalizationModule.forRoot(createLocalizationConfiguration),
    TranslateModule.forRoot({loader: translateLoaderProvider}),
    NgbModule.forRoot(),
    StoreModule.forRoot(rootReducers, {metaReducers}),
    StoreModule.forFeature('superCart', reducers),
    EffectsModule.forRoot([]),
    StoreRouterConnectingModule,
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    BrowserAnimationsModule,

    ...(config.DEBUG_MODE ? [StoreDevtoolsModule.instrument({maxAge: config.DEVTOOL_HISTORY_SIZE})] : []),

    // components:
    SimpleHeaderPresModule,
    FooterPresModule,
    ListInlineMessagesContModule,
    SpinnerBooking3dModule,
    FlightIdentifierModule,

    // services
    CartModule,
    OrderModule,
    AirSearchCriteriaModule.forRoot({airSearchCriteriaService: AirSearchCriteriaService}),
    AirOfferModule.forRoot({airOfferService: AirOfferService})
  ],
  declarations: [AppComponent],
  bootstrap: [AppComponent],
  providers: [{provide: RouterStateSerializer, useClass: CustomSerializer}]
})
export class AppModule {}
