import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {AirSearchContConfig} from '@otter/components';
import {Configurable} from '@otter/core';
import {AirSearchCriteriaService} from '../../../services/src/air-search-criteria/air-search-criteria.service';

import {filter, skip} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';
import {SearchConfig} from './search.config';

@Component({
  selector: 'o3r-search',
  styleUrls: ['./search.style.scss'],
  templateUrl: './search.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchComponent implements OnInit, OnDestroy, Configurable<SearchConfig> {
  /**
   * Configuration of the component
   * @Input
   */
  @Input() public config: SearchConfig;

  public airSearchConfig: AirSearchContConfig;

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  private subscriptions: Subscription[] = [];

  constructor(config: SearchConfig, private router: Router, public searchCriteriaService: AirSearchCriteriaService) {
    this.config = config;
    this.airSearchConfig = new AirSearchContConfig();
    this.airSearchConfig.presenter.basicAirSearchConfig.presenter.flexibilityInputConfig.flexibility = 0;
  }

  ngOnInit() {
    this.subscriptions.push(
      this.searchCriteriaService.searchCriteriaInstance$
        .pipe(
          skip(1),
          filter((search) => !!search)
        )
        .subscribe((searchState) => {
          this.router.navigate([!!searchState && searchState.flexibility ? '/calendar' : '/upsell']);
        })
    );
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
