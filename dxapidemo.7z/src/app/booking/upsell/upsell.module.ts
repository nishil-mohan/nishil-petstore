import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {RouterModule} from '@angular/router';

import {CalendarPerBoundContModule, CircularSpinnerModule, PriceModule, UpsellBoundContModule} from '@otter/components';
import {AirOfferModule} from '../../../services/src/air-offer';

import {NgbTabsetModule} from '@ng-bootstrap/ng-bootstrap';
import {CalendarPerBoundHistogramPresModule} from '@otter/components';
import {SuperCartService} from '../../../service/super-cart/super-cart.service';
import {AirSearchCriteriaModule} from '../../../services/src/air-search-criteria';
import {UpsellComponent} from './upsell.component';
import {UpsellConfig} from './upsell.config';

@NgModule({
  imports: [
    RouterModule.forChild([{path: '', component: UpsellComponent}]),
    CommonModule,

    // Upsell page components
    CalendarPerBoundContModule,
    CalendarPerBoundHistogramPresModule,
    CircularSpinnerModule,
    UpsellBoundContModule,
    NgbTabsetModule,
    PriceModule,

    // Service
    AirOfferModule,
    AirSearchCriteriaModule
  ],
  declarations: [UpsellComponent],
  exports: [UpsellComponent],
  providers: [UpsellConfig, SuperCartService]
})
export class UpsellModule {}
