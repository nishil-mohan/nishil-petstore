import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {utils} from '@dapi/sdk-core';
import {reviveAirSearchCriteria} from '@dapi/sdk/models';
import {Configurable} from '@otter/core';
import {AirCalendarService, CartService} from '@otter/services';
import {AirOfferService} from '../../../services/src/air-offer/air-offer.service';
import {AirSearchCriteriaService} from '../../../services/src/air-search-criteria/air-search-criteria.service';

import {combineLatest, filter, take} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';

import {Amount} from '@dapi/sdkmodels';
import {NgbTabChangeEvent} from '@ng-bootstrap/ng-bootstrap';
import {SuperCartService} from '../../../service/super-cart/super-cart.service';
import {UpsellConfig} from './upsell.config';

@Component({
  selector: 'o3r-upsell',
  styleUrls: ['./upsell.style.scss'],
  templateUrl: './upsell.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UpsellComponent implements OnInit, OnDestroy, Configurable<UpsellConfig> {
  /**
   * Configuration of the component
   * @Input
   */
  @Input() public config: UpsellConfig;

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  public airSearchCriterias: any;
  public airSearchCriteriaIds: any;

  public lowestPricePerSearchCriteria: ({amount: Amount | undefined; value: number} | undefined)[] = [];

  constructor(
    config: UpsellConfig,
    private router: Router,
    public offerService: AirOfferService,
    private airCalendarService: AirCalendarService,
    private cartService: CartService,
    private superCartService: SuperCartService,
    public searchCriteriaService: AirSearchCriteriaService
  ) {
    this.config = config;
  }

  ngOnInit() {
    this.searchCriteriaService.activeSearchCriterias$.subscribe((activeSearchCriterias) => (this.airSearchCriterias = activeSearchCriterias));
    this.searchCriteriaService.activeSearchCriteriaIds$.subscribe((activeSearchCriteriaIds) => (this.airSearchCriteriaIds = activeSearchCriteriaIds));
    this.subscriptions.push(
      this.airCalendarService.selectedDates$
        .pipe(
          filter((dates) => dates && dates.length > 0),
          combineLatest(this.searchCriteriaService.searchCriteriaInstance$, (dates, searchState) => {
            const searchCriteria = reviveAirSearchCriteria(searchState);
            if (searchCriteria && searchCriteria.bounds && searchCriteria.bounds.length > 0) {
              if (dates[0]) {
                searchCriteria.bounds[0].departureDateTime = new utils.DateTime(dates[0]);
              }
              if (dates[1] && searchCriteria.bounds.length > 1) {
                searchCriteria.bounds[1].departureDateTime = new utils.DateTime(dates[1]);
              }
            }
            return searchCriteria;
          }),
          filter((searchCriteria) => !!searchCriteria)
        )
        .subscribe((searchCriteria) => this.offerService.loadOffers(searchCriteria!))
    );

    this.offerService.test$.subscribe((newval) => {
      console.log(newval);
      newval.forEach((amount, index) => {
        if (amount) {
          this.lowestPricePerSearchCriteria[index] = amount;
        }
      });
    });
  }

  /**
   * Callback of the Back button
   */
  goBack() {
    this.searchCriteriaService.searchCriteriaInstance$
      .pipe(
        take(1),
        filter((searchState) => !!searchState)
      )
      .subscribe((searchState) => {
        this.router.navigate([searchState && searchState.flexibility ? '/calendar' : '/search']);
      });
  }

  /**
   * Callback of the Continue button
   */
  goNext() {
    this.cartService.clearAllCart();
    this.addAirOfferToCart();
    this.router.navigate(['/fare']);
  }

  /**
   * Add Offers to the Super cart
   */
  addAirOfferToSuperCart() {
    this.offerService.viewedOffer$
      .pipe(
        take(1),
        filter((viewedOffer) => !!viewedOffer)
      )
      .subscribe((viewedOffer) => this.superCartService.addAirOfferToCart(viewedOffer!));
    window.scrollTo(0, 0);
  }

  /**
   * Add Offers to the current cart
   */
  addAirOfferToCart() {
    this.subscriptions.push(
      this.offerService.viewedOffer$
        .pipe(
          take(1),
          filter((viewedOffer) => !!viewedOffer)
        )
        .subscribe((viewedOffer) => this.cartService.addAirOfferToCart(viewedOffer!))
    );
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

  changeTab(event: NgbTabChangeEvent) {
    // console.log("changeTab ", airSearchCriteria);
    // Update the selected air search criteria
    // event.activeId
    this.searchCriteriaService.selectSearchCriteriaById((event.nextId as any).id);
  }
}
