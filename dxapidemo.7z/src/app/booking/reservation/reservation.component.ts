import {ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Order} from '@dapi/sdk/models';
import {Configurable} from '@otter/core';
import {OrderService} from '@otter/services';

import {filter} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';

import {ReservationConfig} from './reservation.config';

@Component({
  selector: 'o3r-reservation',
  styleUrls: ['./reservation.style.scss'],
  templateUrl: './reservation.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ReservationComponent implements OnInit, OnDestroy, Configurable<ReservationConfig> {
  /**
   * Configuration of the component
   * @Input
   */
  @Input() public config: ReservationConfig;

  /**
   * The current order
   */
  public order: Order;

  /**
   * Show or hide the order details
   */
  private showOrderDetails: boolean = false;

  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  constructor(config: ReservationConfig, private orderService: OrderService, private router: Router) {
    this.config = config;
  }

  ngOnInit() {
    this.subscriptions.push(this.orderService.checkoutState$.pipe(filter((state) => !!state)).subscribe((state) => (this.order = state.entities[state.ids[0]])));
  }

  goNext() {
    // No logic yet
    this.router.navigate(['/search']);
  }

  toggleOrderDetails() {
    this.showOrderDetails = !this.showOrderDetails;
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
