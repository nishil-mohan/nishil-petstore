import {Component, Input} from '@angular/core';
import {Router} from '@angular/router';
import {LocalizationService} from '@otter/common';
import {Block, Configurable, InputConfig} from '@otter/core';
import {SimpleHeaderPresConfig} from './simple-header-pres.config';
import {SimpleHeaderPresContext} from './simple-header-pres.context';

@Component({
  selector: 'o3r-simple-header-pres',
  styleUrls: ['./simple-header-pres.style.scss'],
  templateUrl: './simple-header-pres.template.html'
})
export class SimpleHeaderPresComponent implements Configurable<SimpleHeaderPresConfig>, SimpleHeaderPresContext, Block {
  /**
   * Configuration of the component
   * @Input
   */
  @Input()
  @InputConfig()
  public config: SimpleHeaderPresConfig;

  constructor(private router: Router, config: SimpleHeaderPresConfig, public localizationService: LocalizationService) {
    this.config = config;
  }

  /**
   * Called upon language change to set current language
   * @param language
   */
  useLanguage(language: string) {
    this.localizationService.useLanguage(language);
  }

  shouldDisplayShoppingBasket() {
    return ['/search', '/calendar', '/upsell', '/fare', '/shopping'].indexOf(this.router.url) >= 0;
  }
}
