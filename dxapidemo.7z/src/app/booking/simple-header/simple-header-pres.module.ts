import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';

import {LocalizationModule} from '@otter/common';

import {SimpleHeaderPresComponent} from './simple-header-pres.component';
import {SimpleHeaderPresConfig} from './simple-header-pres.config';
import {ShoppingBasketModule} from './sub-components/shopping-basket/shopping-basket.module';

@NgModule({
  imports: [CommonModule, LocalizationModule, ShoppingBasketModule],
  declarations: [SimpleHeaderPresComponent],
  exports: [SimpleHeaderPresComponent],
  providers: [SimpleHeaderPresConfig]
})
export class SimpleHeaderPresModule {}
