import {Context} from '@otter/common';

export interface SimpleHeaderPresContext extends Context {}
