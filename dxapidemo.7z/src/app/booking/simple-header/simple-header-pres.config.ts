import {Injectable} from '@angular/core';
import {Configuration} from '@otter/core';

@Injectable()
export class SimpleHeaderPresConfig implements Configuration {
  /**
   * Show the motto on the right of the screen
   */
  public showMotto: boolean = true;

  /**
   * Show language selection dropdown (localization)
   */
  public showLanguageSelector: boolean = true;
}
