import {ChangeDetectionStrategy, Component} from '@angular/core';
import {Router} from '@angular/router';
import {AirOfferItem, Amount, Cart} from '@dapi/sdk';
import {SuperCartService} from '../../../../../service/super-cart/super-cart.service';

@Component({
  selector: 'shopping-basket',
  templateUrl: './shopping-basket.template.html',
  styleUrls: ['./shopping-basket.style.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ShoppingBasketComponent {
  protected expanded: boolean;
  constructor(private router: Router, protected superCart: SuperCartService) {
    this.expanded = false;
  }

  ngOnInit() {
    this.superCart.retrieveCartList(['002MQPO029HMQ2GO', '002MQLLPQ0VHI20C', '002MQLOP4THNU20O']);
  }

  getOriginLocation(cart: Cart): string {
    return cart.airOffers ? cart.airOffers[0].offerItems[0].air.bounds[0].originLocationCode : '';
  }

  getDestinationLocation(cart: Cart): string {
    return cart.airOffers ? cart.airOffers[0].offerItems[0].air.bounds[0].destinationLocationCode : '';
  }

  getTotalPrice(cart: Cart): Amount | null {
    const totalPrices = cart.airOffers ? cart.airOffers[0].offerItems[0].prices.totalPrices : null;
    return totalPrices ? totalPrices[0].totalAmount : null;
  }

  getOffer(cart: Cart): AirOfferItem | null {
    return cart.airOffers ? cart.airOffers[0].offerItems[0] : null;
  }

  goToMyCart() {
    this.router.navigate(['/shopping']);
  }
}
