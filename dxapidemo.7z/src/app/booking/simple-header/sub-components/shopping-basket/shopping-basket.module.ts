import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {MatCardModule, MatDividerModule} from '@angular/material';
import {SuperCartService} from '../../../../../service/super-cart/super-cart.service';
import {CartItemTitleModule} from '../../../super-cart/cart-item/sub-components/cart-item-title/cart-item-title.module';
import {ShoppingBasketComponent} from './shopping-basket.component';

@NgModule({
  imports: [
    CommonModule,
    MatCardModule,
    MatDividerModule,
    CartItemTitleModule
  ],
  declarations: [
    ShoppingBasketComponent
  ],
  exports: [
    ShoppingBasketComponent
  ],
  providers: [
    SuperCartService
  ]
})
export class ShoppingBasketModule {}
