import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {MatExpansionModule} from '@angular/material/expansion';
import {RouterModule} from '@angular/router';

import {CartContModule, CartPresModule} from '@otter/components';
import {CartModule} from '@otter/services';

import {SuperCartService} from '../../../service/super-cart/super-cart.service';
import {CartItemComponent} from './cart-item/cart-item.component';
import {CartItemTitleModule} from './cart-item/sub-components/cart-item-title/cart-item-title.module';
import {SuperCartComponent} from './super-cart.component';

@NgModule({
  imports: [
    RouterModule.forChild([{path: '', component: SuperCartComponent}]),
    CommonModule,
    MatExpansionModule,
    CartPresModule,
    CartItemTitleModule,

    CartModule,
    // Fare page components
    CartContModule
  ],
  declarations: [SuperCartComponent, CartItemComponent],
  exports: [SuperCartComponent],
  providers: [SuperCartService]
})
export class SuperCartModule {}
