import {ChangeDetectionStrategy, Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {Subscription} from 'rxjs/Subscription';
import {SuperCartService} from '../../../service/super-cart/super-cart.service';


@Component({
  selector: 'super-cart',
  styleUrls: ['./super-cart.style.scss'],
  templateUrl: './super-cart.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SuperCartComponent implements OnInit, OnDestroy {


  /**
   * List of subscriptions to unsuscribe on destroy
   */
  protected subscriptions: Subscription[] = [];

  constructor(private router: Router, private superCart: SuperCartService) {}// }, private rout: ActivatedRoute) {}

  id: string;

  ngOnInit() {
    // Run on component initialization
    // this.subcriptions = this.rout.params.subscribe((params) => {
    //   this.id = params['id'];
    //   var superCartId = atob(this.id);
    //   var cartIds = superCartId.split('!', 3);
    //   this.superCart.retrieveCartList(cartIds);
    // });

    // Run on component initialization
    this.superCart.retrieveCartList(['002MQPO029HMQ2GO', '002MQLLPQ0VHI20C', '002MQLOP4THNU20O']);
  }

  goBack() {
    // no logic yet
    this.router.navigate(['/upsell']);
  }

  goNext() {
    // no logic yet
    this.router.navigate(['/traveler']);
  }

  ngOnDestroy() {
    // clean the subscriptions
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }
}
