import {ChangeDetectionStrategy, Component, Input} from '@angular/core';
import {AirOfferItem} from '@dapi/sdk/models';
import {Amount} from '@dapi/sdk/models/base/Amount';

@Component({
  selector: 'cart-item-title',
  templateUrl: 'cart-item-title.template.html',
  styleUrls: ['cart-item-title.style.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CartItemTitleComponent {
  @Input() originLocationCode: string;
  @Input() destinationLocationCode: string;
  @Input() price: Amount;

  @Input() offer: AirOfferItem;

  ngOnInit() {
    if (!this.price) {
      this.price = {amount: '', currencyCode: '', currency: {name: '', decimalPlaces: 0}};
    }
  }
}
