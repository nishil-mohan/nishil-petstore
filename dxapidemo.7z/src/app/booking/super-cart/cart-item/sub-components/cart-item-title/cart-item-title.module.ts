import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {PriceModule} from '@otter/components';
import {CartItemTitleComponent} from './cart-item-title.component';

@NgModule({
  imports: [
    CommonModule,
    PriceModule
  ],
  declarations: [
    CartItemTitleComponent
  ],
  exports: [
    CartItemTitleComponent
  ]
})
export class CartItemTitleModule {}
