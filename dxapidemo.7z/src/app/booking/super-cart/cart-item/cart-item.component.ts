import {ChangeDetectionStrategy, Component, Input} from '@angular/core';
import {Router} from '@angular/router';
import {AirOfferItem, Amount, Cart} from '@dapi/sdk';
import {CartService} from '@otter/services';

@Component({
  selector: 'cart-item',
  templateUrl: 'cart-item.template.html',
  styleUrls: ['cart-item.style.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CartItemComponent {
  @Input() cart: Cart;

  protected cartExpanded: boolean;

  constructor(private cartService: CartService, private router: Router) {
    this.cartExpanded = false;
  }

  getOriginLocation(cart: Cart): string {
    return cart.airOffers ? cart.airOffers[0].offerItems[0].air.bounds[0].originLocationCode : '';
  }

  getDestinationLocation(cart: Cart): string {
    return cart.airOffers ? cart.airOffers[0].offerItems[0].air.bounds[0].destinationLocationCode : '';
  }

  getTotalPrice(cart: Cart): Amount | null {
    const totalPrices = cart.airOffers ? cart.airOffers[0].offerItems[0].prices.totalPrices : null;
    return totalPrices ? totalPrices[0].totalAmount : null;
  }

  getOffer(cart: Cart): AirOfferItem | null {
    return cart.airOffers ? cart.airOffers[0].offerItems[0] : null;
  }

  selectCart(cart: Cart) {
    this.cartService.retrieveCart(cart.id);
    this.router.navigate(['/traveler']);
  }
}
