import {O3rPageFixture} from '@otter/common/dist/testing/core';

export class FareFixture extends O3rPageFixture {
  /* selectors */
  protected readonly BACK_BTN = '#back-btn';
  protected readonly NEXT_BTN = '#next-btn';

  /**
   * Clicks on Go Back button
   */
  async back() {
    return this.throwOnUndefined(await this.query(this.BACK_BTN)).click();
  }

  /**
   * Clicks on Go Next button
   */
  async validate() {
    return this.throwOnUndefined(await this.query(this.NEXT_BTN)).click();
  }
}
