export * from './fare.module';
