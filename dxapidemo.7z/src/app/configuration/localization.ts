import {LocalizationConfiguration} from '@otter/core';
import {config} from '@otter/core';

import localeAR from '@angular/common/locales/ar';
import localeEN from '@angular/common/locales/en';
import localeFR from '@angular/common/locales/fr';

/**
 * pass this function to LocalizationModule.forRoot to configure the module
 */
export function createLocalizationConfiguration(): LocalizationConfiguration {
  /**
   * Creates configuration for LocalizationModule. Only supportedLocales param is mandatory.
   * Other params language, endPointUrl, rtlLanguages, fallbackLanguage are optional
   * and have default values:
   *   - language = "en" (english texts displayed by default)
   *   - endPointUrl = "" (empty meaning that the translations loader will target src/assets/i18n folder)
   *   - rtlLanguages = ["ar", "he"] Arabic and Hebrew at the moment
   *   - fallbackLanguage = "en"
   * Fell free to specify any configuration that suits your needs
   */
  const locConfig: LocalizationConfiguration = new LocalizationConfiguration([localeEN, localeFR, localeAR]);
  locConfig.bundlesOutputPath = config.LOCALIZATION_BUNDLES_OUTPUT;
  return locConfig;
}
