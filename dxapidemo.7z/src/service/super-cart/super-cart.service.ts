import {Injectable} from '@angular/core';
import {AirOffer, CartApi, CartReply} from '@dapi/sdk';
import {createFeatureSelector, createSelector, MemoizedSelector, Store} from '@ngrx/store';
// import {Cart} from '@otter/store';
import {Observable} from 'rxjs/Observable';
import {Add} from '../../store/shopping-basket/shopping-basket.actions';
import {adapter} from '../../store/shopping-basket/shopping-basket.reducer';
import {
  ShoppingBasketCart,
  ShoppingBasketState,
  SuperCartState
} from '../../store/shopping-basket/shopping-basket.state';
// import { take} from 'rxjs/operators';

export const superCartState: MemoizedSelector<object, SuperCartState> =
    createFeatureSelector('superCart');

export const getFirstCartState: MemoizedSelector<object, ShoppingBasketCart> = createSelector(
    superCartState,
    (state: SuperCartState) => state.cartIdList.entities[state.cartIdList.ids[0]]
);

export const getSecondCartState: MemoizedSelector<object, ShoppingBasketCart> = createSelector(
    superCartState,
    (state: SuperCartState) => state.cartIdList.entities[state.cartIdList.ids[1]]
);

export const getThirdCartState: MemoizedSelector<object, ShoppingBasketCart> = createSelector(
    superCartState,
    (state: SuperCartState) => state.cartIdList.entities[state.cartIdList.ids[2]]
);

export const getCartLength: MemoizedSelector<object, number> = createSelector(
    superCartState,
    (state: SuperCartState) => state.cartIdList.ids.length
);

export const getAllCarts: MemoizedSelector<object, ShoppingBasketCart[]> = createSelector(
    superCartState,
    (state: SuperCartState) => adapter.getSelectors().selectAll(state.cartIdList)
);

@Injectable()
export class SuperCartService {

  cartLenght$: Observable<number>;

  carts$: Observable<ShoppingBasketCart[]>;

  cart1$: Observable<ShoppingBasketCart>;
  cart2$: Observable<ShoppingBasketCart>;
  cart3$: Observable<ShoppingBasketCart>;

  protected api: CartApi;


  // retrievedCart$: Observable<CartReply>;

  constructor(api: CartApi, public store: Store<ShoppingBasketState>) {
    this.api = api;

    this.cart1$ = this.store.select(getFirstCartState);
    this.cart2$ = this.store.select(getSecondCartState);
    this.cart3$ = this.store.select(getThirdCartState);
    this.cartLenght$ = this.store.select(getCartLength);
    this.carts$ = this.store.select(getAllCarts);

    this.carts$.subscribe((data: ShoppingBasketCart[]) => {
      console.log('data', data);
    });
  }

  addAirOfferToCart(airOffer: AirOffer) {
    this.api.createCart({airOfferId: airOffer.id}).then((res: CartReply) => {
      this.store.dispatch(new Add({id: airOffer.id, data: res.data}));
    });

  }

  retrieveCartList(cartIds: string[]) {
    cartIds.forEach((cartId) => {
      this.api.retrieveCart({cartId: cartId}).then((res: CartReply) => {
        // this.store.dispatch(new Add({id: cartId, data: res.data}));
      });
    });

    // 002MQLLPQ0VHI20C
    // 002MQLOP4THNU20O
  }
}
