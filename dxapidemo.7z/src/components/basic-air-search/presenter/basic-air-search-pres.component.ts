import {ChangeDetectionStrategy, Component, EventEmitter, Input, Output, TemplateRef} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {utils} from '@dapi/sdk-core/fwk';
import {LocationDictionaryItem} from '@dapi/sdk/models';
import {TemplateContext, UuidGenerator} from '@otter/common';
import {Configurable, InputConfig} from '@otter/core';

import {
  CabinInputPresConfig,
  CabinInputPresContext,
  CabinInputPresContextInput,
  FlexibilityInputPresConfig,
  FlexibilityInputPresContext,
  FlexibilityInputPresContextInput,
  LocationInputPresConfig,
  LocationInputPresContext,
  LocationInputPresContextInput,
  PassengersInputPresConfig,
  PassengersInputPresContext,
  PassengersInputPresContextInput
} from '@otter/components';
import {DateInputConfig} from '@otter/components/dist/elements/input/date-input/date-input.config';
import {DateInputContext, DateInputContextInput} from '@otter/components/dist/elements/input/date-input/date-input.context';

import {BasicAirSearchPresConfig} from './basic-air-search-pres.config';
import {BasicAirSearchPresContext} from './basic-air-search-pres.context';

@Component({
  selector: 'qr-basic-air-search-pres',
  styleUrls: ['./basic-air-search-pres.style.scss'],
  templateUrl: './basic-air-search-pres.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BasicAirSearchPresComponent implements Configurable<BasicAirSearchPresConfig>, BasicAirSearchPresContext {
  /**
   * Configuration of the component
   * @Input
   */
  @Input()
  @InputConfig()
  public config: BasicAirSearchPresConfig;

  /**
   * Boolean to specify if the search is for a one way trip or not. If it is false, the trip type is round trip.
   */
  @Input() isOneWay: boolean;

  /**
   * Template to use for displaying the location input
   */
  @Input() locationInputTemplate?: TemplateRef<LocationInputPresContext>;

  /**
   * Template to use for displaying the date input
   */
  @Input() dateInputTemplate?: TemplateRef<DateInputContext>;

  /**
   * Template to use for displaying the passengers input component
   */
  @Input() passengersInputTemplate?: TemplateRef<PassengersInputPresContext>;

  /**
   * Template to use for displaying the cabin input component
   */
  @Input() cabinInputTemplate?: TemplateRef<CabinInputPresContext>;

  /**
   * Template to use for displaying the flexibility input component
   */
  @Input() flexibilityInputTemplate?: TemplateRef<FlexibilityInputPresContext>;

  /**
   * Observable of locations used as input for the departure LocationInputComponent.
   */
  @Input() departureLocations: LocationDictionaryItem[];

  /**
   * Observable of locations used as input for the arrival LocationInputComponent.
   */
  @Input() arrivalLocations: LocationDictionaryItem[];

  /**
   * Form group of the component.
   */
  @Input() searchForm: FormGroup | undefined;

  /**
   * Travelers object used to create the traveler FormGroup into the BasicSearch model.
   */
  @Input() travelers: {[key: string]: number};

  /**
   * Minimum date used as input for the departure date component (DateInputComponent).
   */
  @Input() departureMinimumDate: utils.DateTime;

  /**
   * Minimum date used as input for the arrival date component (DateInputComponent).
   * When a valid date has been selected for the departure, the minimum date of the arrival date component will be
   * updated to the new selected value.
   */
  @Input() arrivalMinimumDate: utils.DateTime;

  /**
   * Maximum date used as input for both arrival and departure date component.
   */
  @Input() maximumDate: utils.DateTime;

  /**
   * Emitter for the submit event
   */
  @Output() onSubmit: EventEmitter<void> = new EventEmitter<void>();

  /**
   * component id
   */
  id: string;

  /**
   * Constants with the name of the form control for both departure and arrival location components.
   */
  private nameDepartureLocationFormControl = 'departureLocation';
  private nameArrivalLocationFormControl = 'arrivalLocation';

  constructor(config: BasicAirSearchPresConfig, uuid: UuidGenerator) {
    this.config = config;
    this.id = uuid.generate();
  }

  /**
   * Function nused to output the submit action to the container component.
   */
  onSubmitEmitter($event: Event) {
    $event.preventDefault();
    this.onSubmit.emit();
  }

  /**
   * Generates the context passed to the template that renders the departure input component.
   */
  getDepartureInputContext(overrideContext: LocationInputPresContextInput): TemplateContext<LocationInputPresConfig, LocationInputPresContextInput> {
    return {
      inputs: {
        locationForm: this.searchForm!,
        nameFormControl: this.nameDepartureLocationFormControl,
        label: 'From',
        inputPlaceholder: 'Departure city or airport',
        locations: [],
        ...overrideContext
      },
      outputs: {},
      config: this.config.departureInputConfig,
      parentId: this.id + '-departureLocation'
    };
  }

  /**
   * Generates the context passed to the template that renders the arrival input component.
   */
  getArrivalInputContext(overrideContext: LocationInputPresContextInput): TemplateContext<LocationInputPresConfig, LocationInputPresContextInput> {
    return {
      inputs: {
        locationForm: this.searchForm!,
        nameFormControl: this.nameArrivalLocationFormControl,
        label: 'To',
        inputPlaceholder: 'Arrival city or airport',
        locations: [],
        ...overrideContext
      },
      outputs: {},
      config: this.config.arrivalInputConfig,
      parentId: this.id + '-arrivalLocation'
    };
  }

  /**
   * Generates the context passed to the template that renders the departure date component.
   */
  getDepartureDateContext(overrideContext?: DateInputContextInput): TemplateContext<DateInputConfig, DateInputContextInput> {
    return {
      inputs: {
        dateForm: this.searchForm!.get('departureDate'),
        label: 'Departure date',
        minimumDate: this.departureMinimumDate,
        maximumDate: this.maximumDate,
        ...overrideContext
      },
      outputs: {},
      config: this.config.departureDateConfig,
      parentId: this.id + '-outboundDate'
    };
  }

  /**
   * Generates the context passed to the template that renders the arrival date component.
   */
  getArrivalDateContext(overrideContext?: Partial<DateInputContextInput>): TemplateContext<DateInputConfig, DateInputContextInput> {
    return {
      inputs: {
        dateForm: this.searchForm!.get('returnDate'),
        label: 'Return date',
        minimumDate: this.arrivalMinimumDate,
        maximumDate: this.maximumDate,
        ...overrideContext
      },
      outputs: {},
      config: this.config.arrivalDateConfig,
      parentId: this.id + '-inboundDate'
    };
  }

  /**
   * Generates the context passed to the template that renders the passenger input component.
   */
  getPassengersInputContext(overrideContext?: Partial<PassengersInputPresContextInput>): TemplateContext<PassengersInputPresConfig, PassengersInputPresContextInput> {
    return {
      inputs: {passengersForm: this.searchForm!.get('travelers'), ...overrideContext},
      outputs: {},
      config: this.config.passengersInputConfig,
      parentId: this.id + '-passengers'
    };
  }

  /**
   * Generates the context passed to the template that renders the cabin input component.
   */
  getCabinInputContext(overrideContext?: Partial<CabinInputPresContextInput>): TemplateContext<CabinInputPresConfig, CabinInputPresContextInput> {
    return {
      inputs: {cabinForm: this.searchForm!.get('cabin'), label: 'Cabin', ...overrideContext},
      outputs: {},
      config: this.config.cabinInputConfig,
      parentId: this.id + '-cabin'
    };
  }

  /**
   * Generates the context passed to the template that renders the flexibility input component.
   */
  getFlexibilityInputContext(overrideContext?: Partial<FlexibilityInputPresContextInput>): TemplateContext<FlexibilityInputPresConfig, FlexibilityInputPresContextInput> {
    return {
      inputs: {flexibilityForm: this.searchForm!.get('flexibility'), label: 'Flexibility', ...overrideContext},
      outputs: {},
      config: this.config.flexibilityInputConfig,
      parentId: this.id + '-flexibility'
    };
  }
}
