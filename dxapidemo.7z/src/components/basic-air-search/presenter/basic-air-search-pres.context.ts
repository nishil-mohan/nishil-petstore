import {TemplateRef} from '@angular/core';
import {FormGroup} from '@angular/forms';
import {utils} from '@dapi/sdk-core/fwk';
import {LocationDictionaryItem} from '@dapi/sdk/models';
import {Context} from '@otter/common';
import {CabinInputPresContext, FlexibilityInputPresContext, LocationInputPresContext, PassengersInputPresContext} from '@otter/components';
import {DateInputContext} from '@otter/components/dist/elements/input/date-input/date-input.context';

export interface BasicAirSearchPresContextInput {
  /**
   * Boolean to specify if the search is for a one way trip or not. If it is false, the trip type is round trip.
   */
  isOneWay: boolean;

  /**
   * Template to use for displaying the location input
   */
  locationInputTemplate?: TemplateRef<LocationInputPresContext>;

  /**
   * Template to use for displaying the date input
   */
  dateInputTemplate?: TemplateRef<DateInputContext>;

  /**
   * Template to use for displaying the passengers input component
   */
  passengersInputTemplate?: TemplateRef<PassengersInputPresContext>;

  /**
   * Template to use for displaying the cabin input component
   */
  cabinInputTemplate?: TemplateRef<CabinInputPresContext>;

  /**
   * Template to use for displaying the flexibility input component
   */
  flexibilityInputTemplate?: TemplateRef<FlexibilityInputPresContext>;

  /**
   * Observable of locations used as input for the departure LocationInputComponent.
   */
  departureLocations: LocationDictionaryItem[];

  /**
   * Observable of locations used as input for the arrival LocationInputComponent.
   */
  arrivalLocations: LocationDictionaryItem[];

  /**
   * Form group of the component.
   */
  searchForm: FormGroup | undefined;

  /**
   * Travelers object used to create the traveler FormGroup into the BasicSearch model.
   */
  travelers: {[key: string]: number};

  /**
   * Minimum date used as input for the departure date component (DateInputComponent).
   */
  departureMinimumDate: utils.DateTime;

  /**
   * Minimum date used as input for the arrival date component (DateInputComponent).
   * When a valid date has been selected for the departure, the minimum date of the arrival date component will be
   * updated to the new selected value.
   */
  arrivalMinimumDate: utils.DateTime;

  /**
   * Maximum date used as input for both arrival and departure date component.
   */
  maximumDate: utils.DateTime;
}

export interface BasicAirSearchPresContextOutput {
  /**
   * Emitter for the submit event
   */
  onSubmit: void;
}

export interface BasicAirSearchPresContext extends Context<BasicAirSearchPresContextInput, BasicAirSearchPresContextOutput> {}
