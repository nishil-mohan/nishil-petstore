import {Injectable} from '@angular/core';
import {Configuration, ErrorMessages} from '@otter/core';

import {CabinInputPresConfig, FlexibilityInputPresConfig, LocationInputPresConfig, PassengersInputPresConfig} from '@otter/components';
import {DateInputConfig} from '@otter/components/dist/elements/input/date-input/date-input.config';

@Injectable()
export class BasicAirSearchPresConfig implements Configuration, ErrorMessages {
  /**
   * Error messages to display when both locations are the same.
   */
  public errorMessages = {identicalLocations: 'Departure and arrival cannot be the same'};

  /**
   * Configuration for the LocationInputComponents.
   */
  public departureInputConfig: LocationInputPresConfig = new LocationInputPresConfig();
  public arrivalInputConfig: LocationInputPresConfig = new LocationInputPresConfig();

  /**
   * Configuration for the DateInputComponent.
   */
  public departureDateConfig: DateInputConfig = new DateInputConfig();
  public arrivalDateConfig: DateInputConfig = new DateInputConfig();

  /**
   * Configuration for the PassengersInput Component.
   */
  public passengersInputConfig: PassengersInputPresConfig = new PassengersInputPresConfig();

  /**
   * Configuration for the CabinInput component
   */
  public cabinInputConfig: CabinInputPresConfig = new CabinInputPresConfig();

  /**
   * Configuration for the FlexibilityInput component
   */
  public flexibilityInputConfig: FlexibilityInputPresConfig = new FlexibilityInputPresConfig();

  constructor() {
    this.departureDateConfig.dateType = 'DateTime';
    this.arrivalDateConfig.dateType = 'DateTime';

    this.arrivalDateConfig.errorMessages.minimumDate = 'Return date cannot be before the departure';
  }
}
