import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {UuidGenerator} from '@otter/common';

import {CabinInputPresModule, FlexibilityInputPresModule, LocationInputPresModule, PassengersInputPresModule} from '@otter/components';
import {DateInputModule} from '@otter/components/dist/elements/input/date-input';

import {BasicAirSearchPresComponent} from './basic-air-search-pres.component';
import {BasicAirSearchPresConfig} from './basic-air-search-pres.config';

import {MultiLocationInputPresModule} from '../../multi-location-input';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CabinInputPresModule,
    FlexibilityInputPresModule,
    LocationInputPresModule,
    MultiLocationInputPresModule,
    PassengersInputPresModule,
    DateInputModule
  ],
  declarations: [BasicAirSearchPresComponent],
  exports: [BasicAirSearchPresComponent, CabinInputPresModule, FlexibilityInputPresModule, LocationInputPresModule, MultiLocationInputPresModule, PassengersInputPresModule, DateInputModule],
  providers: [BasicAirSearchPresConfig, UuidGenerator]
})
export class BasicAirSearchPresModule {}
