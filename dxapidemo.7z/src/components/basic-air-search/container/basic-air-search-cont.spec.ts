import {Component} from '@angular/core';
import {ComponentFixture, getTestBed, TestBed} from '@angular/core/testing';
import {FormBuilder, FormGroup, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from '@angular/platform-browser-dynamic/testing';
import {utils} from '@dapi/sdk-core/fwk';
import {AirSearchCriteria, LocationDictionaryItem, SearchBound} from '@dapi/sdk/models';
import {UuidGenerator} from '@otter/common';
import {CatalogsService} from '@otter/services';
import {Subject} from 'rxjs/Subject';
import {AirSearchCriteriaService} from '../../../services/src/air-search-criteria/air-search-criteria.service';

import {BasicAirSearchContComponent} from './basic-air-search-cont.component';
import {BasicAirSearchContConfig} from './basic-air-search-cont.config';
import {BasicAirSearchCont} from './basic-air-search-cont.model';

@Component({
  selector: 'qr-basic-air-search-pres',
  template: '',
  inputs: [
    'config',
    'isOneWay',
    'arrivalMinimumDate',
    'cabinInputTemplate',
    'dateInputTemplate',
    'departureMinimumDate',
    'flexibilityInputTemplate',
    'locationInputTemplate',
    'maximumDate',
    'passengersInputTemplate',
    'searchForm',
    'travelers',
    'departureLocations',
    'arrivalLocations'
  ]
})
@Component({
  selector: 'o3r-location-input-pres',
  template: '',
  inputs: ['config', 'locations', 'locationForm', 'nameFormControl', 'inputPlaceholder', 'label', 'id']
})
class MockLocationInputComponent {}

@Component({selector: 'o3r-passengers-input-pres', template: '', inputs: ['config', 'passengersForm', 'id']})
class MockPassengersInputComponent {}

@Component({
  selector: 'o3r-date-input',
  template: '',
  inputs: ['config', 'dateForm', 'label', 'minimumDate', 'maximumDate', 'id']
})
class MockDateInputComponent {}

@Component({selector: 'o3r-cabin-input-pres', template: '', inputs: ['config', 'cabinForm', 'label']})
class MockCabinInputComponent {}

@Component({selector: 'o3r-flexibility-input-pres', template: '', inputs: ['config', 'flexibilityForm', 'label']})
class MockFlexibilityInputComponent {}

xdescribe('BasicSearchCriteriaContComponent', () => {
  beforeAll(() => getTestBed().platform || TestBed.initTestEnvironment(BrowserDynamicTestingModule, platformBrowserDynamicTesting()));

  let fixture: ComponentFixture<BasicAirSearchContComponent>;
  let instance: BasicAirSearchContComponent;
  let formBuilder: FormBuilder = new FormBuilder();
  let searchCriteriaServiceMock: {searchCriteriaInstance$: any; updateSearchCriteria: any};
  let catalogServiceMock: {locationsInstance$: any; loadLocations: any};

  const flexibility = 0;
  const dateDeparture = new utils.DateTime(2017, 5, 15);
  const dateArrival = new utils.DateTime(2017, 5, 17);
  const departureCode = 'NCE';
  const arrivalCode = 'LON';
  const travelers = ['1ADT', '0CHD', '0INF'];
  const bound1: SearchBound = {
    departureDateTime: dateDeparture,
    originLocationCode: departureCode,
    destinationLocationCode: arrivalCode
  };
  const bound2: SearchBound = {
    departureDateTime: dateArrival,
    originLocationCode: arrivalCode,
    destinationLocationCode: departureCode
  };
  const searchCriteria: AirSearchCriteria = {
    bounds: [bound1, bound2],
    flexibility,
    cabin: 'Economy',
    commercialFareFamilies: ['ECONOMY1'],
    travelers,
    languageCode: 'GB'
  };
  const subjectSearchCriteria = new Subject<AirSearchCriteria>();

  const location1: LocationDictionaryItem = {type: 'airport', airportName: 'Nice', cityCode: 'NCE'};
  const location2: LocationDictionaryItem = {type: 'airport', airportName: 'London', cityCode: 'LON'};
  const locationList: LocationDictionaryItem[] = [location1, location2];
  const subjectLocation = new Subject<LocationDictionaryItem[]>();

  const isOneWay = true;
  const cabin = 'Economy';
  const travelersObject = {ADT: 1, CHD: 0, INF: 0};
  const commercialFareFamily = ['ECONOMY1'];
  const languageCode = 'GB';
  const departureDateFormControlName = 'departureDate';
  const arrivalDateFormControlName = 'returnDate';

  const travelerForm: FormGroup = formBuilder.group(travelersObject);
  const basicAirSearchOW: BasicAirSearchCont = new BasicAirSearchCont(
    isOneWay,
    undefined,
    null,
    dateDeparture,
    dateArrival,
    flexibility,
    cabin,
    travelerForm.value,
    commercialFareFamily,
    languageCode
  );
  const basicAirSearchRT = new BasicAirSearchCont(false, location1, location2, dateDeparture, dateArrival, flexibility, cabin, travelerForm.value, commercialFareFamily, languageCode);

  beforeEach(async (done) => {
    searchCriteriaServiceMock = {
      searchCriteriaInstance$: subjectSearchCriteria,
      updateSearchCriteria: jasmine.createSpy('updateSearchCriteria')
    };

    catalogServiceMock = {locationsInstance$: subjectLocation, loadLocations: jasmine.createSpy('loadLocations')};

    await TestBed.configureTestingModule({
      declarations: [BasicAirSearchContComponent, MockLocationInputComponent, MockPassengersInputComponent, MockDateInputComponent, MockCabinInputComponent, MockFlexibilityInputComponent],
      imports: [BrowserModule, FormsModule, ReactiveFormsModule],
      providers: [
        BasicAirSearchContConfig,
        {provide: AirSearchCriteriaService, useValue: searchCriteriaServiceMock},
        {provide: CatalogsService, useValue: catalogServiceMock},
        {provide: UuidGenerator, useValue: {generate: () => 'fakeId'}}
      ]
    }).compileComponents();
    done();
  });

  beforeEach(async (done) => {
    formBuilder = new FormBuilder();
    fixture = TestBed.createComponent(BasicAirSearchContComponent);
    instance = fixture.componentInstance;
    done();
  });

  describe('ngOnInit', () => {
    it('should initialize the searchForm with a OW model', () => {
      const form = formBuilder.group(basicAirSearchOW);
      fixture.detectChanges();
      subjectLocation.next([location1]);
      instance.searchForm.get(departureDateFormControlName).setValue(dateDeparture);
      instance.searchForm.get(arrivalDateFormControlName).setValue(dateArrival);
      fixture.detectChanges();
      expect(instance.searchForm.value).toEqual(form.value);
    });

    it('should initialize the searchForm with a RT model', () => {
      instance.config.shouldLoadSearchFromStore = true;
      fixture.detectChanges();
      subjectSearchCriteria.next(searchCriteria);
      subjectLocation.next(locationList);
      fixture.detectChanges();
      const form = formBuilder.group(basicAirSearchRT);
      instance.searchForm.get('departureDate').setValue(dateDeparture);
      instance.searchForm.get('returnDate').setValue(dateArrival);
      expect(instance.searchForm.value).toEqual(form.value);
    });
  });

  describe('createForm', () => {
    it('should create a searchForm with a OW model', () => {
      fixture.detectChanges();
      instance.createForm(locationList);
      const form = formBuilder.group(basicAirSearchOW);
      instance.searchForm.get(departureDateFormControlName).setValue(dateDeparture);
      instance.searchForm.get(arrivalDateFormControlName).setValue(dateArrival);
      expect(instance.searchForm.value).toEqual(form.value);
    });

    it('should create a searchForm with a RT model', () => {
      fixture.detectChanges();
      instance.createForm(locationList, searchCriteria);
      const form = formBuilder.group(basicAirSearchRT);
      instance.searchForm.get(departureDateFormControlName).setValue(dateDeparture);
      instance.searchForm.get(arrivalDateFormControlName).setValue(dateArrival);
      expect(instance.searchForm.value).toEqual(form.value);
    });
  });

  describe('getLocationList', () => {
    it('should return the entire location list', () => {
      expect(instance.getLocationList('', locationList)).toEqual(locationList);
    });

    it('should create a searchForm with a RT model', () => {
      expect(instance.getLocationList(location1, locationList)).toEqual([location2]);
    });
  });

  describe('onSubmit', () => {
    it('should return the entire location list', () => {
      instance.searchForm = formBuilder.group(basicAirSearchRT);
      fixture.detectChanges();
      instance.onSubmit();
      expect(searchCriteriaServiceMock.updateSearchCriteria).toHaveBeenCalled();
    });
  });
});
