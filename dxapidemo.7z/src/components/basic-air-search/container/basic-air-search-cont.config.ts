import {Injectable} from '@angular/core';
import {utils} from '@dapi/sdk-core/fwk';
import {Configuration} from '@otter/core';
import {BasicAirSearchPresConfig} from '../presenter';

@Injectable()
export class BasicAirSearchContConfig implements Configuration {
  /**
   * Boolean to specify if the search should be filled on loaded based on the state of the Search Criteria store.
   */
  public shouldLoadSearchFromStore: boolean = false;

  /**
   * Minimum date of the date inputs.
   * By default, the value is today.
   */
  public minimumDate: utils.DateTime = this.createDateTime(0);

  /**
   * Maximum date of the date inputs.
   * By default the value is today + 330 days.
   */
  public maximumDate: utils.DateTime = this.createDateTime(330 * 24);

  /**
   * Configuration for basic air search presenter
   */
  public presenter: BasicAirSearchPresConfig = new BasicAirSearchPresConfig();

  private createDateTime(hours: number) {
    const date = new Date();
    return new utils.DateTime(date.getFullYear(), date.getMonth(), date.getDate(), hours, 0, 0, 0);
  }
}
