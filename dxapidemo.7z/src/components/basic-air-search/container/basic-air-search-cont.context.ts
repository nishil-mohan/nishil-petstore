import {TemplateRef} from '@angular/core';
import {Context} from '@otter/common';
import {CabinInputPresContext, FlexibilityInputPresContext, LocationInputPresContext, PassengersInputPresContext} from '@otter/components';
import {DateInputContext} from '@otter/components/dist/elements/input/date-input/date-input.context';
import {BasicAirSearchPresContext} from '../presenter/basic-air-search-pres.context';

export interface BasicAirSearchContContextInput {
  /**
   * Boolean to specify if the search is for a one way trip or not. If it is false, the trip type is round trip.
   */
  isOneWay: boolean;

  /**
   * Template for basic air search presenter
   */
  basicAirSearchPresenterTemplate?: TemplateRef<BasicAirSearchPresContext>;

  /**
   * Template to use for displaying the location input
   */
  locationInputTemplate?: TemplateRef<LocationInputPresContext>;

  /**
   * Template to use for displaying the date input
   */
  dateInputTemplate?: TemplateRef<DateInputContext>;

  /**
   * Template to use for displaying the passengers input component
   */
  passengersInputTemplate?: TemplateRef<PassengersInputPresContext>;

  /**
   * Template to use for displaying the cabin input component
   */
  cabinInputTemplate?: TemplateRef<CabinInputPresContext>;

  /**
   * Template to use for displaying the flexibility input component
   */
  flexibilityInputTemplate?: TemplateRef<FlexibilityInputPresContext>;
}

export interface BasicAirSearchContContext extends Context<BasicAirSearchContContextInput> {}
