import {FormBuilder, FormGroup} from '@angular/forms';
import {utils} from '@dapi/sdk-core/fwk';
import {AirSearchCriteria, LocationDictionaryItem, SearchBound} from '@dapi/sdk/models';

export class BasicAirSearchCont {
  /**
   * Boolean to specify if the Basic Search is a One Way travel type.
   */
  public isOneWay: boolean;

  /**
   * Location for the departure.
   */
  public departureLocation?: LocationDictionaryItem;

  /**
   * Location for the arrival.
   */
  public arrivalLocation?: LocationDictionaryItem;

  /**
   * Departure date.
   */
  public departureDate?: utils.DateTime;

  /**
   * Return date.
   */
  public returnDate?: utils.DateTime;

  /**
   * Number of flexible days for the search.
   */
  public flexibility?: number;

  /**
   * Cabin
   */
  public cabin?: string;

  /**
   * Form group for the traveler.
   * It should contain an object for the date with the following structure:
   * {travelerType: numberOfTraveler}
   * Example: {ADT: 1, CHD:1, INF:1}
   */
  public travelers?: FormGroup;

  /**
   * Commercial fare family list.
   */
  public commercialFareFamily?: string[];

  /**
   * Language code.
   */
  public languageCode?: string;

  constructor(
    isOneWay: boolean,
    departureLocation?: LocationDictionaryItem,
    arrivalLocation?: LocationDictionaryItem,
    departureDate?: utils.DateTime,
    returnDate?: utils.DateTime,
    flexibility?: number,
    cabin?: string,
    travelers?: FormGroup,
    commercialFareFamily?: string[],
    languageCode?: string
  ) {
    this.isOneWay = isOneWay;
    this.departureLocation = departureLocation;
    this.arrivalLocation = arrivalLocation;
    this.departureDate = departureDate;
    this.returnDate = returnDate;
    this.flexibility = flexibility;
    this.cabin = cabin;
    this.travelers = travelers;
    this.commercialFareFamily = commercialFareFamily;
    this.languageCode = languageCode;
  }

  /**
   * This function creates an object AirSearchCriteria from the current BasicAirSearch instance.
   * It creates an array of SearchBound (one way or round trip based on the attribute isOneWay), create the
   * traveler list and return a new instance of AirSearchCriteria.
   */
  public createAirSearchCriteria(): AirSearchCriteria {
    // TMP: Use of cityCode. For now the location object does not contain any airportCode
    const bounds: SearchBound[] = [];
    bounds.push({
      departureDateTime: this.departureDate,
      originLocationCode: this.departureLocation && this.departureLocation.cityCode,
      destinationLocationCode: this.arrivalLocation && this.arrivalLocation.cityCode
    });
    if (!this.isOneWay) {
      bounds.push({
        departureDateTime: this.returnDate,
        originLocationCode: this.arrivalLocation && this.arrivalLocation.cityCode,
        destinationLocationCode: this.departureLocation && this.departureLocation.cityCode
      });
    }
    const travelerList = this.getTravelerList();
    return {
      bounds: bounds,
      flexibility: this.flexibility,
      cabin: this.cabin,
      commercialFareFamilies: this.commercialFareFamily,
      travelers: travelerList,
      languageCode: this.languageCode
    };
  }

  /**
   * This function returns a list of travelers from the map of travelers stored into the formGroup travelers.
   * The array returned has the following structure:
   *  - ["TypeOfTraveler-NbOfTraveler"]: example: ["ADT-1", "CHD-1", "INF-1"]
   */
  public getTravelerList() {
    const travelers = this.travelers;
    return (
      travelers &&
      Object.keys(travelers)
        .filter((travelerType) => travelers[travelerType] > 0)
        .map((travelerType) => `${travelers[travelerType]}${travelerType}`)
    );
  }

  /**
   * This function instantiate the BasicAirSearch attributes from an AirSearchCriteria and a list of locations.
   * If the AirSearchCriteria has two bounds, the model will be initialized as a round trip flight with the attribute
   * isOneWay to false and a return date.
   * @param airSearchCriteria
   * @param locations
   */
  public instantiateFromAirSearchCriteria(airSearchCriteria: AirSearchCriteria, locations: LocationDictionaryItem[]) {
    if (airSearchCriteria.bounds && airSearchCriteria.bounds.length > 0) {
      this.isOneWay = true;
      this.cabin = airSearchCriteria.cabin;
      this.flexibility = airSearchCriteria.flexibility;
      this.commercialFareFamily = airSearchCriteria.commercialFareFamilies;
      this.languageCode = airSearchCriteria.languageCode;
      this.departureDate = airSearchCriteria.bounds[0].departureDateTime;
      this.returnDate = airSearchCriteria.bounds[0].departureDateTime;
      this.updateLocations(airSearchCriteria.bounds[0], locations);
      if (airSearchCriteria.bounds.length === 2) {
        this.isOneWay = false;
        this.returnDate = airSearchCriteria.bounds[1].departureDateTime;
      }
      if (airSearchCriteria.travelers) {
        this.createTravelerList(airSearchCriteria.travelers);
      }
    }
  }

  /**
   * Function to update location attributes (departureLocation, arrivalLocation) based on a SearchBound and a list
   * of LocationDictionary. It looks for the originLocationCode and destinationLocationCode of the bound into
   * the locations list. When it found the location, it updates the corresponding attribute (departureLocation or
   * arrivalLocation).
   * @param bound
   * @param locations
   */
  public updateLocations(bound: SearchBound, locations: LocationDictionaryItem[]) {
    let index = 0;
    let originFound = false;
    let destinationFound = false;
    while ((!originFound || !destinationFound) && index < locations.length) {
      if (locations[index].cityCode === bound.originLocationCode) {
        this.departureLocation = locations[index];
        originFound = true;
      }
      if (locations[index].cityCode === bound.destinationLocationCode) {
        this.arrivalLocation = locations[index];
        destinationFound = true;
      }
      index++;
    }
  }

  /**
   * Function to create a list of traveler from an array of string with the following structure:
   *  - ["TypeOfTraveler-NbOfTraveler"]: example: ["ADT-1", "CHD-1", "INF-1"]
   * It initializes the travelers as FormGroup with a map of travelers:
   *  - {TypeOfTraveler: NbOfTraveler}: example: {ADT: 2, CHD: 1, INF: 1}
   * @param travelerTypes:
   */
  public createTravelerList(travelerTypes: string[]) {
    const travelerList: {[key: string]: number} = {ADT: 0, CHD: 0, INF: 0};
    for (const travelerType of travelerTypes) {
      const travelerNbByType = this.getTravelerNbByType(travelerType);
      if (travelerNbByType) {
        travelerList[travelerNbByType.type] = travelerNbByType.number;
      }
    }
    const formBuilder = new FormBuilder();
    this.travelers = formBuilder.group(travelerList);
  }

  /**
   * Function to get the number of travelers per type. It takes in parameter a string with the following structure:
   * - ["NbOfTravelerTypeOfTraveler"]: example: ["1ADT"]
   * And returns an object with the type and the number from the parameter.
   * @param travelerNbAndType
   */
  public getTravelerNbByType(travelerNbAndType: string) {
    const travelerNbByType = travelerNbAndType.match(/(\d+)(\w+)/);
    return (
      travelerNbByType && {
        type: travelerNbByType[2],
        number: +travelerNbByType[1]
      }
    );
  }
}
