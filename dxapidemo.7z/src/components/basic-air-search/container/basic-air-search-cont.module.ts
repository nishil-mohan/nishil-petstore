import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {UuidGenerator} from '@otter/common';
import {CatalogsServiceModule} from '@otter/services';
import {AirOfferModule} from '../../../services/src/air-offer';
import {AirSearchCriteriaModule} from '../../../services/src/air-search-criteria';

import {BasicAirSearchPresModule} from '../presenter';

import {BasicAirSearchContComponent} from './basic-air-search-cont.component';
import {BasicAirSearchContConfig} from './basic-air-search-cont.config';

@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, AirSearchCriteriaModule, AirOfferModule, BasicAirSearchPresModule, CatalogsServiceModule],
  declarations: [BasicAirSearchContComponent],
  exports: [BasicAirSearchContComponent],
  providers: [BasicAirSearchContConfig, UuidGenerator]
})
export class BasicAirSearchContModule {}
