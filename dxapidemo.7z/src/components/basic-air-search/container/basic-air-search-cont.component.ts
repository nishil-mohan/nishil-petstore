import {ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, TemplateRef} from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {utils} from '@dapi/sdk-core/fwk';
import {AirSearchCriteria, LocationDictionaryItem} from '@dapi/sdk/models';
import {TemplateContext, UuidGenerator} from '@otter/common';
import {Configurable, InputConfig} from '@otter/core';
import {CatalogsService} from '@otter/services';
import {Observable} from 'rxjs/Observable';
import {combineLatest, filter, startWith, take} from 'rxjs/operators';
import {Subscription} from 'rxjs/Subscription';

import {CabinInputPresContext, FlexibilityInputPresContext, LocationInputPresContext, PassengersInputPresContext} from '@otter/components';
import {DateInputContext} from '@otter/components/dist/elements/input/date-input/date-input.context';

import {AirSearchCriteriaService} from '../../../services/src/air-search-criteria/air-search-criteria.service';

import {BasicAirSearchPresConfig, BasicAirSearchPresContext, BasicAirSearchPresContextInput, BasicAirSearchPresContextOutput} from '../presenter';
import {BasicAirSearchContConfig} from './basic-air-search-cont.config';
import {BasicAirSearchContContext} from './basic-air-search-cont.context';
import {BasicAirSearchCont} from './basic-air-search-cont.model';

@Component({
  selector: 'qr-basic-air-search-cont',
  templateUrl: './basic-air-search-cont.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BasicAirSearchContComponent implements OnInit, OnDestroy, Configurable<BasicAirSearchContConfig>, BasicAirSearchContContext {
  private subscriptions: Subscription[] = [];

  /**
   * Configuration of the component
   * @Input
   */
  @Input()
  @InputConfig()
  public config: BasicAirSearchContConfig;

  /**
   * Boolean to specify if the search is for a one way trip or not. If it is false, the trip type is round trip.
   */
  @Input() isOneWay: boolean;

  /**
   * Template to use for displaying the basic air search presenter component
   */
  @Input() basicAirSearchPresenterTemplate?: TemplateRef<BasicAirSearchPresContext>;

  /**
   * Template to use for displaying the location input
   */
  @Input() locationInputTemplate?: TemplateRef<LocationInputPresContext>;

  /**
   * Template to use for displaying the date input
   */
  @Input() dateInputTemplate?: TemplateRef<DateInputContext>;

  /**
   * Template to use for displaying the passengers input component
   */
  @Input() passengersInputTemplate?: TemplateRef<PassengersInputPresContext>;

  /**
   * Template to use for displaying the cabin input component
   */
  @Input() cabinInputTemplate?: TemplateRef<CabinInputPresContext>;

  /**
   * Template to use for displaying the flexibility input component
   */
  @Input() flexibilityInputTemplate?: TemplateRef<FlexibilityInputPresContext>;

  /**
   * Observable of locations used as input for the departure LocationInputComponent.
   */
  departureLocations$: Observable<LocationDictionaryItem[]>;

  /**
   * Observable of locations used as input for the arrival LocationInputComponent.
   */
  arrivalLocations$: Observable<LocationDictionaryItem[]>;

  /**
   * Form group of the component.
   */
  searchForm: FormGroup | undefined;

  /**
   * Travelers object used to create the traveler FormGroup into the BasicSearch model.
   */
  travelers: {[key: string]: number};

  /**
   * Minimum date used as input for the departure date component (DateInputComponent).
   */
  departureMinimumDate: utils.DateTime;

  /**
   * Minimum date used as input for the arrival date component (DateInputComponent).
   * When a valid date has been selected for the departure, the minimum date of the arrival date component will be
   * updated to the new selected value.
   */
  arrivalMinimumDate: utils.DateTime;

  /**
   * Maximum date used as input for both arrival and departure date component.
   */
  maximumDate: utils.DateTime;

  /**
   * component id
   */
  id: string;

  /**
   * Constants with the name of the form control for both departure and arrival location components.
   */
  private nameDepartureLocationFormControl = 'departureLocation';
  private nameArrivalLocationFormControl = 'arrivalLocation';

  /**
   * Observable of locations
   */
  private locations$: Observable<LocationDictionaryItem[]>;

  constructor(
    config: BasicAirSearchContConfig,
    private formBuilder: FormBuilder,
    private searchCriteriaService: AirSearchCriteriaService,
    private catalogsService: CatalogsService,
    private changeDetector: ChangeDetectorRef,
    uuid: UuidGenerator
  ) {
    this.config = config;
    this.isOneWay = true;
    this.departureMinimumDate = this.config.minimumDate;
    this.arrivalMinimumDate = this.config.minimumDate;
    this.maximumDate = this.config.maximumDate;
    this.travelers = {ADT: 1, CHD: 0, INF: 0};
    this.id = uuid.generate();
  }

  ngOnInit() {
    this.catalogsService.loadLocations();
    this.locations$ = this.catalogsService.locationsInstance$;

    if (this.config.shouldLoadSearchFromStore) {
      this.subscriptions.push(
        this.locations$.pipe(combineLatest(this.searchCriteriaService.searchCriteriaInstance$), take(1)).subscribe((state) => {
          this.createForm(state[0], state[1]);
        })
      );
    } else {
      this.subscriptions.push(this.locations$.pipe(filter((locations) => !!locations), take(1)).subscribe((locations) => this.createForm(locations)));
    }
  }

  /**
   * Function createForm.
   * It sets the model of the search form. A search form model is a BasicSearch.
   * It also sets the Observables of locations used for the departure and location inputs and the minimum date
   * of for the arrival date input.
   */
  createForm(locations: LocationDictionaryItem[], airSearchCriteria?: AirSearchCriteria) {
    const travelers = this.formBuilder.group(this.travelers);
    const basicSearch = new BasicAirSearchCont(
      this.isOneWay,
      undefined,
      undefined,
      new utils.DateTime(),
      this.isOneWay ? undefined : new utils.DateTime(),
      0,
      this.config.presenter.cabinInputConfig.cabinOptions[0],
      travelers,
      ['ECONOMY1'],
      'GB'
    );

    if (airSearchCriteria) {
      basicSearch.instantiateFromAirSearchCriteria(airSearchCriteria, locations);
    }
    this.searchForm = this.formBuilder.group(basicSearch);
    const departureDate = this.searchForm.get('departureDate');
    if (departureDate) {
      this.subscriptions.push(departureDate.valueChanges.subscribe((date) => (this.arrivalMinimumDate = date)));
    }
    this.searchForm.updateValueAndValidity();

    const departureFormControl = this.searchForm.get(this.nameDepartureLocationFormControl);
    if (departureFormControl) {
      this.arrivalLocations$ = this.locations$.pipe(
        combineLatest(basicSearch.departureLocation ? departureFormControl.valueChanges.pipe(startWith(basicSearch.departureLocation)) : departureFormControl.valueChanges, (locationList, value) =>
          this.getLocationList(value, locationList)
        )
      );
    }

    const arrivalFormControl = this.searchForm.get(this.nameArrivalLocationFormControl);
    if (arrivalFormControl) {
      this.departureLocations$ = this.locations$;
      // TODO filter out arrival locations selected.
    }
    this.changeDetector.markForCheck();
  }

  /**
   * Function to get the list of locations. It takes in parameter a specific location and a list. If the selected
   * location is a string (it means the user is writing in the location input), the function returns the complete list.
   * Else, it filter the list with the selected location.
   * @param selectedLocation
   * @param locations
   */
  getLocationList(selectedLocation: string | LocationDictionaryItem | null, locations: LocationDictionaryItem[]): LocationDictionaryItem[] {
    return typeof selectedLocation === 'string' || selectedLocation === null ? locations : locations.filter((location) => location !== selectedLocation);
  }

  /**
   * Function called on form submission.
   * It creates a AirSearchCriteria object from the form model (BasicAirSearch). Then it adds the search into
   * the SearchCriteria store through the search criteria service.
   */
  onSubmit() {
    if (this.searchForm) {
      const isOneWayFromControl = this.searchForm.get('isOneWay');
      const arrivalList = this.searchForm.get('arrivalLocation');
      if (arrivalList && arrivalList.value) {
        const arrivalLocations = arrivalList.value;
        const searchCriterias: AirSearchCriteria[] = [];
        arrivalLocations.forEach((location: LocationDictionaryItem) => {
          const basicSearchCriteria = new BasicAirSearchCont(this.isOneWay);
          const rawData = this.searchForm!.getRawValue();
          rawData.arrivalLocation = location;
          Object.assign(basicSearchCriteria, rawData);
          searchCriterias.push(basicSearchCriteria.createAirSearchCriteria());
        });
        this.searchCriteriaService.addSearchCriterias(searchCriterias);
        this.searchCriteriaService.selectSearchCriteria(searchCriterias[0]);
      } else {
        if (isOneWayFromControl) {
          isOneWayFromControl.setValue(this.isOneWay);
          // Object.assign(basicAirSearch, this.searchForm.getRawValue());
        }
      }
    }
    // const airSearchCriteria: AirSearchCriteria = basicAirSearch.createAirSearchCriteria();
  }

  ngOnDestroy() {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

  /**
   * Generates the context passed to the template that renders the basic air search presentercomponent.
   */
  getBasicAirSearchPresenterContext(
    overrideContextInput?: Partial<BasicAirSearchPresContextInput>
  ): TemplateContext<BasicAirSearchPresConfig, BasicAirSearchPresContextInput, BasicAirSearchPresContextOutput> {
    return {
      inputs: {
        isOneWay: this.isOneWay,
        arrivalLocations: [],
        departureLocations: [],
        arrivalMinimumDate: this.arrivalMinimumDate,
        cabinInputTemplate: this.cabinInputTemplate,
        dateInputTemplate: this.dateInputTemplate,
        departureMinimumDate: this.departureMinimumDate,
        flexibilityInputTemplate: this.flexibilityInputTemplate,
        locationInputTemplate: this.locationInputTemplate,
        maximumDate: this.maximumDate,
        passengersInputTemplate: this.passengersInputTemplate,
        searchForm: this.searchForm,
        travelers: this.travelers,
        ...overrideContextInput
      },
      outputs: {
        onSubmit: this.onSubmit.bind(this)
      },
      config: this.config.presenter || new BasicAirSearchPresConfig()
    };
  }
}
