import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {ChangeDetectionStrategy, Component, ElementRef, Input, OnInit, ViewChild} from '@angular/core';
import {AbstractControl, FormControl, FormGroup} from '@angular/forms';
import {MatAutocompleteSelectedEvent, MatChipInputEvent} from '@angular/material';
import {LocationDictionaryItem, reviveLocationDictionaryItem} from '@dapi/sdk/models';
import {UuidGenerator} from '@otter/common';
import {Configurable, InputConfig} from '@otter/core';
import {Observable} from 'rxjs/Observable';
import {map} from 'rxjs/operators';

import {MultiLocationInputPresConfig} from './multi-location-input-pres.config';
import {MultiLocationInputPresContext} from './multi-location-input-pres.context';

@Component({
  selector: 'qr-multi-location-input-pres',
  styleUrls: ['./multi-location-input-pres.style.scss'],
  templateUrl: './multi-location-input-pres.template.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MultiLocationInputPresComponent implements OnInit, Configurable<MultiLocationInputPresConfig>, MultiLocationInputPresContext {
  /**
   * Configuration of the component
   * @Input
   */
  @Input()
  @InputConfig()
  public config: MultiLocationInputPresConfig;

  /**
   * Form group instance in which the component is currently used.
   * We have to specify it to be able update the model of the form when the value of the input (linked to the
   * the form control name) has been modified.
   */
  @Input() locationForm: FormGroup;

  /**
   * Name of the form control. The name corresponds to the attribute into the form group we want to modify through
   * the input.
   */
  @Input() nameFormControl: string;

  /**
   * Placeholder to display into the input.
   */
  @Input() inputPlaceholder: string;

  /**
   * Label before the input. The label should be always provided to ensure the accessibility of the input field.
   * The field shouldDisplaySpan into LocationInputPresConfig allows you to show/hide the text.
   */
  @Input() label: string;

  /**
   * Location list.
   */
  @Input() locations: LocationDictionaryItem[];

  /**
   * Id of the HTML input of the component.
   */
  id: string;

  formControl: AbstractControl | null;

  visible: boolean = true;
  selectable: boolean = true;
  removable: boolean = true;
  addOnBlur: boolean = false;

  separatorKeysCodes = [ENTER, COMMA];

  locationCtrl = new FormControl();

  filteredLocations: Observable<LocationDictionaryItem[]>;

  selectedLocations: LocationDictionaryItem[] = [];

  @ViewChild('locInput') locInput: ElementRef;

  constructor(config: MultiLocationInputPresConfig, uuid: UuidGenerator) {
    this.config = config;
    this.id = uuid.generate();
    this.filteredLocations = this.locationCtrl.valueChanges.pipe(map((location: LocationDictionaryItem | string) => (location ? this.filter(location) : this.locations.slice())));
  }

  ngOnInit() {
    this.formControl = this.locationForm.get(this.nameFormControl);
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our location
    if ((value || '').trim()) {
      this.selectedLocations.push(reviveLocationDictionaryItem(value)!);
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.locationCtrl.setValue(null);
  }

  remove(location: any): void {
    const index = this.selectedLocations.indexOf(location);

    if (index >= 0) {
      this.selectedLocations.splice(index, 1);
    }
  }

  filter(name: string | LocationDictionaryItem) {
    if (typeof name === 'string') {
      return this.locations.filter((location) => this.locationMatchesAsPrefix(location, name));
    } else {
      return this.locations.filter((location) => this.locationMatchesAsPrefixItem(location, name));
    }
  }

  locationMatchesAsPrefix(location: LocationDictionaryItem, userInput: string) {
    return (
      (location.cityCode && location.cityCode.toUpperCase().startsWith(userInput.toUpperCase())) ||
      (location.airportName && location.airportName.toUpperCase().startsWith(userInput.toUpperCase())) ||
      this.formatResult(location).startsWith(userInput)
    );
  }

  locationMatchesAsPrefixItem(location: LocationDictionaryItem, userInput: LocationDictionaryItem) {
    return (
      (location.cityCode && userInput.cityCode && location.cityCode.toUpperCase().startsWith(userInput.cityCode.toUpperCase())) ||
      (location.airportName && userInput.airportName && location.airportName.toUpperCase().startsWith(userInput.airportName.toUpperCase())) ||
      this.formatResult(location).startsWith(this.formatResult(userInput))
    );
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.selectedLocations.push(event.option.value);
    this.locInput.nativeElement.value = '';
    this.locationCtrl.setValue(null);

    if (this.formControl) {
      this.formControl.setValue(this.selectedLocations);
    }
  }

  formatResult(result: LocationDictionaryItem) {
    let formattedResult = '';
    if (result && result.airportName && result.cityCode) {
      delete result.type;
      formattedResult = result.airportName.toUpperCase() + '(' + result.cityCode.toUpperCase() + ')';
    }
    return formattedResult;
  }
}
