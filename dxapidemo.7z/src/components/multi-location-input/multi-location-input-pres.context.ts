import {FormGroup} from '@angular/forms';
import {LocationDictionaryItem} from '@dapi/sdk/models';
import {Context} from '@otter/common';

export interface MultiLocationInputPresContextInput {
  /**
   * Form group instance in which the component is currently used.
   */
  locationForm: FormGroup;

  /**
   * Name of the form control. The name corresponds to the attribute into the form group we want to modify through
   * the input.
   */
  nameFormControl: string;

  /**
   * Placeholder to display into the input.
   */
  inputPlaceholder: string;

  /**
   * Label before the input. The label should be always provided to ensure the accessibility of the input field.
   * The field shouldDisplaySpan into LocationInputConfig allows you to show/hide the text.
   */
  label: string;

  /**
   * Location list.
   */
  locations: LocationDictionaryItem[];
}

export interface MultiLocationInputPresContext extends Context<MultiLocationInputPresContextInput> {}
