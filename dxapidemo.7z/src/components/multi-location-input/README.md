# Component Description

This item allows the user to type a city name or airport code, and will propose suggestion(s) to the user, based on what is being typed.

| Given | When | Then |
|---|---|---|
| A location input is displayed and empty | As soon as the user starts typing | Suggestion list appears |
| A location input is displayed | The user types an unknown location | Suggestion list disappears<br> |
| Suggestion list is displayed | User clicks on a specific suggestion |  Selected suggestion is set as location in associated input|

# Business Logic

---
Not applicable at this level.
Please check associated block(s) description.

# Input Validation

| Input | Status | Validation Check | Validation Behaviour |
|---|---|---|---|
| Location | Mandatory | Accepts only alphabetic characters | Standard / generic validation feedback.<br>Associated labels: <br>"Invalid location" |

# Error Management

Not applicable

# Configuration Description

---
| Parameter Name | Description | Possible Values (Default) |
|---|---|---|
| shouldActivateTypeahead | Determines if the suggestion feature is enabled (true) or not (false) | Boolean (True) |
| label | Defines the location input label | String |
| shouldDisplaySpan | Determines if the location input label is displayed (true) or not (false) | Boolean (True) |
| minLength | Determines the minimum input length  | Any numeric value |
| isRequired | Determines if the input is mandatory (true) or not (false) | Boolean (True) |
| nbOfLocationsToDisplay | Determines the maximum number of suggestion in the list when the feature is enabled| Any numeric value (10) |
| inputPlaceholder | Defines the example text shown in the input when it's empty | String |
