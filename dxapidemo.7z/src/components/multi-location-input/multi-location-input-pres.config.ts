import {Injectable} from '@angular/core';
import {Configuration} from '@otter/core';

@Injectable()
export class MultiLocationInputPresConfig implements Configuration {}
