import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {UuidGenerator} from '@otter/common';

import {MatAutocompleteModule, MatChipsModule, MatFormFieldModule, MatIconModule} from '@angular/material';
import {MultiLocationInputPresComponent} from './multi-location-input-pres.component';
import {MultiLocationInputPresConfig} from './multi-location-input-pres.config';

@NgModule({
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatChipsModule, MatAutocompleteModule, MatFormFieldModule, MatIconModule],
  declarations: [MultiLocationInputPresComponent],
  exports: [MultiLocationInputPresComponent],
  providers: [MultiLocationInputPresConfig, UuidGenerator]
})
export class MultiLocationInputPresModule {}
