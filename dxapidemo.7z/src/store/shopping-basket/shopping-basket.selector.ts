import {createFeatureSelector, createSelector, MemoizedSelector} from '@ngrx/store';
import {adapter} from './shopping-basket.reducer';
import {ShoppingBasketState} from './shopping-basket.state';

export const selectSuperCartState: MemoizedSelector<object, ShoppingBasketState> = createFeatureSelector('superCart');

const selectors = adapter.getSelectors();

export const selectAll: any = createSelector(selectSuperCartState, selectors.selectAll);
export const selectAllCarts: any = createSelector(selectAll, (state) => state);
// export const selectCurrentCartId = createSelector(selectSuperCartState, (state) => state.);
