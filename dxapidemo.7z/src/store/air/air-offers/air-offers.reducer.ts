import {AirOffer} from '@dapi/sdk/models';
import {createEntityAdapter, EntityAdapter} from '@ngrx/entity';

import {StateStatus} from '@otter/core';
import {ActionTypes, AvailableActions} from './air-offers.actions';
import {Model, State, StateDetails} from './air-offers.state';

export const adapter: EntityAdapter<Model> = createEntityAdapter<Model>();

export const initialState: State = adapter.getInitialState<StateDetails>({stateStatus: StateStatus.ready, selectedAirOfferId: null});

/**
 * Reducer of the AirOffers store
 */
export function reducer(state: State = initialState, action: AvailableActions) {
  const createModel = (airOffer: AirOffer) => ({...airOffer, stateStatus: StateStatus.ready});

  switch (action.type) {
    // Update the specific offer after Retrieve call return
    case ActionTypes.UPDATE_OFFER: {
      return adapter.updateOne({id: action.payload.data.id, changes: createModel(action.payload.data)}, state);
    }

    // Set the offer status as Loading and wait for the Retrieve call result
    case ActionTypes.RETRIEVE_OFFER: {
      return adapter.updateOne({id: action.payload.id, changes: {stateStatus: StateStatus.loading}}, state);
    }

    // If the Retrieve call failed, the offer status is set to Loaded and the error is attached to the Offer
    case ActionTypes.FAIL_OFFER: {
      return adapter.updateOne({id: action.payload.id, changes: {stateStatus: StateStatus.failed}}, state);
    }

    // Update the list of offers with the ones received
    case ActionTypes.SET: {
      return adapter.addAll(
        action.payload.data.airOffers.map((model) => ({
          ...model,
          stateStatus: StateStatus.ready,
          searchCriteriaId: action.id
        })),
        initialState
      );
    }

    // Load offers list
    case ActionTypes.LOAD: {
      return {...state, stateStatus: StateStatus.loading};
    }

    // Load offers failed
    case ActionTypes.FAIL: {
      return {...state, stateStatus: StateStatus.failed};
    }

    // Clear offers
    case ActionTypes.CLEAR_ALL: {
      return initialState;
    }

    // Select an offer
    case ActionTypes.SELECT_OFFER: {
      return {...state, selectedAirOfferId: action.payload.id};
    }

    // Clear selected offer
    case ActionTypes.CLEAR_SELECTION: {
      return {...state, selectedAirOfferId: null};
    }

    default:
      return state;
  }
}
