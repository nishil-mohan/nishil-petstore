import {Injectable} from '@angular/core';
import {Actions as RxActions, Effect} from '@ngrx/effects';
import {Observable} from 'rxjs/Observable';
import {fromPromise as observableFromPromise} from 'rxjs/observable/fromPromise';
import {of as observableOf} from 'rxjs/observable/of';
import {catchError, map, mergeMap} from 'rxjs/operators';

import {modifySelectionActions} from '../air-search-criteria/air-search-criteria.actions';
import {Actions, ActionTypes} from './air-offers.actions';

/**
 * Service to handle async AirOffers actions
 */
@Injectable()
export class AirOffersEffect {
  /**
   * Load the Air Offer list
   */
  @Effect()
  load$: Observable<any> = this.actions$.ofType<Actions.Load>(ActionTypes.LOAD).pipe(
    mergeMap((action: Actions.Load) =>
      observableFromPromise(action.asyncPayload).pipe(
        map((reply) => {
          return new Actions.Set(reply, action.payload);
        }),
        catchError((err) => observableOf(new Actions.Fail(err)))
      )
    )
  );

  /**
   * Retrieve a specific offer
   */
  @Effect()
  retrieve$ = this.actions$.ofType<Actions.RetrieveOffer>(ActionTypes.RETRIEVE_OFFER).pipe(
    mergeMap((action: Actions.RetrieveOffer) =>
      observableFromPromise(action.asyncPayload).pipe(
        map((reply) => new Actions.UpdateOffer(reply)),
        catchError((err) => observableOf(new Actions.FailOffer({id: action.payload.id}, err)))
      )
    )
  );

  /**
   * Clear Offers list on Search update
   */
  @Effect() resetOffersOnNewSearch$ = this.actions$.ofType(...modifySelectionActions).pipe(map(() => new Actions.ClearAll()));

  constructor(protected actions$: RxActions) {}
}
