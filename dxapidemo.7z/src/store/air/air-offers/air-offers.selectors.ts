import {createFeatureSelector, createSelector, MemoizedSelector} from '@ngrx/store';
import {AvailableStores} from '@otter/store';
import {adapter} from './air-offers.reducer';
import {Model, State} from './air-offers.state';

export const selectAirOffersState: MemoizedSelector<object, State> = createFeatureSelector(AvailableStores.airOffers);

const selectors = adapter.getSelectors();

/** select the array of AirOffers ids */
export const selectAirOffersIds = createSelector(selectAirOffersState, selectors.selectIds);

/** select the array of AirOffers */
export const selectAllAirOffers = createSelector(selectAirOffersState, selectors.selectAll);

/** select the dictionary of air offers entities */
export const selectAirOffersEntities: MemoizedSelector<object, {[x: string]: Model}> = createSelector(selectAirOffersState, selectors.selectEntities);

/** select the total AirOffers count */
export const selectAirOffersTotal = createSelector(selectAirOffersState, selectors.selectTotal);

/** select the list of selected airOffers Id */
export const selectCurrentAirOfferId = createSelector(selectAirOffersState, (state) => state.selectedAirOfferId);

/** select the list of selected airOffers */
export const selectCurrentAirOffer = createSelector(selectAirOffersEntities, selectCurrentAirOfferId, (airOffers, id): Model | null => (id ? airOffers[id] : null));
