import {FactoryProvider, InjectionToken, Optional} from '@angular/core';
import {Actions} from '@ngrx/effects';

import {AirOffersEffect} from './air-offers.effect';
import * as AirOffers from './air-offers.reducer';

export const AIR_OFFERS_EFFECT_TOKEN = new InjectionToken('AIR_OFFERS_EFFECT_TOKEN');
export const AIR_OFFERS_REDUCER_TOKEN = new InjectionToken('AIR_OFFERS_TOKEN_REDUCER_TOKEN');
export const AIR_OFFERS_REDUCER_REGISTRATION_TOKEN = new InjectionToken('AIR_OFFERS_REDUCER_REGISTRATION_TOKEN');

export function createAirOffersEffect(customEffect: any, actions: Actions) {
  return customEffect ? customEffect : new AirOffersEffect(actions);
}

export const airOffersEffectProvider: FactoryProvider = {
  provide: AirOffersEffect,
  useFactory: createAirOffersEffect,
  deps: [[new Optional(), AIR_OFFERS_EFFECT_TOKEN], Actions]
};

export function createAirOffersReducer(customReducer: any) {
  return customReducer ? customReducer : AirOffers.reducer;
}

export const airOffersReducerProvider: FactoryProvider = {
  provide: AIR_OFFERS_REDUCER_REGISTRATION_TOKEN,
  useFactory: createAirOffersReducer,
  deps: [[new Optional(), AIR_OFFERS_REDUCER_TOKEN]]
};
