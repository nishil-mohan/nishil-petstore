import {ModuleWithProviders, NgModule, Type} from '@angular/core';
import {EffectsModule} from '@ngrx/effects';
import {StoreModule} from '@ngrx/store';

import {AvailableStores} from '@otter/store';

import {AirOffersEffect} from './air-offers.effect';
import {AIR_OFFERS_EFFECT_TOKEN, AIR_OFFERS_REDUCER_REGISTRATION_TOKEN, AIR_OFFERS_REDUCER_TOKEN, airOffersEffectProvider, airOffersReducerProvider} from './air-offers.providers';

export {Actions, ActionTypes, AvailableActions} from './air-offers.actions';

export * from './air-offers.effect';
export * from './air-offers.reducer';
export * from './air-offers.selectors';
export * from './air-offers.state';
export * from './air-offers.sync';

export interface CustomAirOffersEffect {
  airOffersEffect?: any;
}

export interface CustomAirOffersReducer {
  airOffersReducer?: any;
}

/**
 * AirOffers effects
 */
export const airOffersEffects: Type<any>[] = [AirOffersEffect];

@NgModule({
  imports: [StoreModule.forFeature(AvailableStores.airOffers, AIR_OFFERS_REDUCER_REGISTRATION_TOKEN), EffectsModule.forFeature(airOffersEffects)],
  providers: [airOffersReducerProvider, airOffersEffectProvider]
})
export class AirOffersModule {
  public static forRoot(reducers?: CustomAirOffersReducer, effects?: CustomAirOffersEffect): ModuleWithProviders {
    const providers = [];
    // custom reducers
    if (reducers && reducers.airOffersReducer) {
      providers.push({provide: AIR_OFFERS_REDUCER_TOKEN, useValue: reducers.airOffersReducer});
    }
    // custom effects
    if (effects && effects.airOffersEffect) {
      providers.push({provide: AIR_OFFERS_EFFECT_TOKEN, useClass: effects.airOffersEffect});
    }
    return {ngModule: AirOffersModule, providers: providers};
  }
}
