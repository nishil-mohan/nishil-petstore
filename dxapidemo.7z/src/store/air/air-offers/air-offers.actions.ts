import {AirOfferReply, AirOffersListReply} from '@dapi/sdk/models';
import {Action} from '@ngrx/store';

/**
 * List of actions for the Calendar SelectedEntry store
 */
export enum ActionTypes {
  LOAD = '[AirOffers] load',
  SET = '[AirOffers] update',
  FAIL = '[AirOffers] fail',
  CLEAR_ALL = '[AirOffers] clear',

  RETRIEVE_OFFER = '[AirOffers] retrieve offer',
  UPDATE_OFFER = '[AirOffers] update offer',
  FAIL_OFFER = '[AirOffers] fail offer',
  SELECT_OFFER = '[AirOffers] select offer',
  CLEAR_SELECTION = '[AirOffers] clear selected offer'
}

export interface SelectOfferPayload {
  /** ID of the offer to select */
  id: string;
}

export interface RetrieveOfferPayload {
  /** ID of the offer to update */
  id: string;
}

export interface FailOfferPayload {
  /** ID of the offer to update */
  id: string;
}

export namespace Actions {
  'use strict';

  /**
   * Action to load the list of offers
   */
  export class Load implements Action {
    readonly type = ActionTypes.LOAD;
    constructor(public asyncPayload: Promise<AirOffersListReply>, public payload: string) {}
  }

  /**
   * Action to update the store with the new list of offers
   */
  export class Set implements Action {
    readonly type = ActionTypes.SET;
    constructor(public payload: AirOffersListReply, public id: string) {}
  }

  /**
   * Action to load the list of offers
   */
  export class RetrieveOffer implements Action {
    readonly type = ActionTypes.RETRIEVE_OFFER;
    constructor(public asyncPayload: Promise<AirOfferReply>, public payload: RetrieveOfferPayload) {}
  }

  /**
   * Action to update a specific offer
   */
  export class UpdateOffer implements Action {
    readonly type = ActionTypes.UPDATE_OFFER;
    constructor(public payload: AirOfferReply) {}
  }

  /**
   * Action to update a specific offer
   */
  export class FailOffer implements Action {
    readonly type = ActionTypes.FAIL_OFFER;
    constructor(public payload: FailOfferPayload, public error?: any) {}
  }

  /**
   * Action of load failure
   */
  export class Fail implements Action {
    readonly type = ActionTypes.FAIL;
    constructor(public error?: any) {}
  }

  /**
   * Action of clear the list of offers
   */
  export class ClearAll implements Action {
    readonly type = ActionTypes.CLEAR_ALL;
    constructor() {}
  }

  /**
   * Action to set the selected offer
   */
  export class SelectOffer implements Action {
    readonly type = ActionTypes.SELECT_OFFER;
    constructor(public payload: SelectOfferPayload) {}
  }

  /**
   * Action to clear selected offer
   */
  export class ClearSelectedOffer implements Action {
    readonly type = ActionTypes.CLEAR_SELECTION;
    constructor() {}
  }
}

/**
 * List of action types for the AirOffer store
 */
export declare type AvailableActions =
  | Actions.Load
  | Actions.Set
  | Actions.Fail
  | Actions.ClearAll
  | Actions.SelectOffer
  | Actions.ClearSelectedOffer
  | Actions.RetrieveOffer
  | Actions.UpdateOffer
  | Actions.FailOffer;
