import {AirOffer} from '@dapi/sdk/models';
import {EntityState} from '@ngrx/entity';

import {AsyncItem, AsyncStateModel} from '@otter/core';

/**
 * AirOffer model
 */
export interface Model extends AsyncStateModel, AirOffer {
  searchCriteriaId: string;
}

/**
 * AirOffer model details
 */
export interface StateDetails extends AsyncItem {
  /** Selected AirOffer ID */
  selectedAirOfferId: string | null;
}

/**
 * AirOffer store state
 */
export interface State extends EntityState<Model>, StateDetails {}
