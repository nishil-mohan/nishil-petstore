import {reviveAirOffer} from '@dapi/sdk/models';
import {Serializer} from '@otter/core';
import {adapter, initialState} from './air-offers.reducer';
import {State} from './air-offers.state';

export const storageSync: Serializer<State> = {
  deserialize: (rawObject: any) => {
    if (!rawObject || !rawObject.ids) {
      return initialState;
    }
    const storeObject = adapter.getInitialState(rawObject);
    for (const id of rawObject.ids) {
      storeObject.entities[id] = reviveAirOffer(rawObject.entities[id]);
    }
    return storeObject;
  }
};
