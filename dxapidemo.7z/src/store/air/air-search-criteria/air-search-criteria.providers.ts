import {FactoryProvider, InjectionToken, Optional} from '@angular/core';

import * as AirSearchCriteria from './air-search-criteria.reducer';

export const AIR_SEARCH_CRITERIA_REDUCER_TOKEN = new InjectionToken('AIR_OFFERS__REDUCER_TOKEN');
export const AIR_SEARCH_CRITERIA_REDUCER_REGISTRATION_TOKEN = new InjectionToken('AIR_OFFERS_REDUCER_REGISTRATION_TOKEN');

export function createAirSearchCriteriaReducer(customReducer: any) {
  return customReducer ? customReducer : AirSearchCriteria.reducer;
}

export const airSearchCriteriaReducerProvider: FactoryProvider = {
  provide: AIR_SEARCH_CRITERIA_REDUCER_REGISTRATION_TOKEN,
  useFactory: createAirSearchCriteriaReducer,
  deps: [[new Optional(), AIR_SEARCH_CRITERIA_REDUCER_TOKEN]]
};
