import {AirSearchCriteria} from '@dapi/sdk/models';
import {Action} from '@ngrx/store';

/**
 * List of actions for the AirSearchCriteria store
 */
export enum ActionTypes {
  SET = '[AirSearchCriteria] update',
  ADD_AND_SELECT = '[AirSearchCriteria] add and select',
  ADD_AND_ACTIVE = '[AirSearchCriteria] add and active',
  ADD_AND_ACTIVE_AND_SELECT = '[AirSearchCriteria] add and active and select',
  ADD = '[AirSearchCriteria] add',
  SELECT = '[AirSearchCriteria] select',
  SELECT_ACTIVE_CRITERIAS = '[AirSearchCriteria] select active criterias',
  CLEAR_ALL = '[AirSearchCriteria] clear',
  CLEAR_SELECTION = '[AirSearchCriteria] clear selection'
}

/**
 * List of actions that modifies (clear or sets) the searchCriteriaId
 */
export const modifySelectionActions: ActionTypes[] = [
  ActionTypes.SET,
  ActionTypes.ADD_AND_SELECT,
  ActionTypes.ADD_AND_ACTIVE,
  ActionTypes.ADD_AND_ACTIVE_AND_SELECT,
  ActionTypes.SELECT,
  ActionTypes.SELECT_ACTIVE_CRITERIAS,
  ActionTypes.CLEAR_ALL,
  ActionTypes.CLEAR_SELECTION
];

export interface SelectPayload {
  /** Id of the airSearchCriteria to select */
  id: string;
}

export namespace Actions {
  'use strict';

  /**
   * Action to update the list pf criterias
   */
  export class Set implements Action {
    readonly type = ActionTypes.SET;
    constructor(public payload: AirSearchCriteria[]) {}
  }

  /**
   * Action to update criteria of an AirSearchCriteria
   */
  export class AddAndSelect implements Action {
    readonly type = ActionTypes.ADD_AND_SELECT;
    constructor(public payload: AirSearchCriteria) {}
  }
  /**
   * Action to update criteria of an AirSearchCriteria
   */
  export class AddAndActive implements Action {
    readonly type = ActionTypes.ADD_AND_ACTIVE;
    constructor(public payload: AirSearchCriteria) {}
  }
  /**
   * Action to update criteria of an AirSearchCriteria
   */
  export class AddAndActiveAndSelect implements Action {
    readonly type = ActionTypes.ADD_AND_ACTIVE_AND_SELECT;
    constructor(public payload: AirSearchCriteria) {}
  }

  /**
   * Action to add a criteria in the list of AirSearchCriterias
   */
  export class Add implements Action {
    readonly type = ActionTypes.ADD;
    constructor(public payload: AirSearchCriteria) {}
  }

  /**
   * Action to select a criteria from the list of AirSearchCriterias
   */
  export class Select implements Action {
    readonly type = ActionTypes.SELECT;
    constructor(public payload: SelectPayload) {}
  }

  /**
   *
   */
  export class SelectActiveCriterias implements Action {
    readonly type = ActionTypes.SELECT_ACTIVE_CRITERIAS;
    constructor(public payload: AirSearchCriteria[]) {}
  }

  /**
   * Action to clear criteria of a AirSearchCriteria
   */
  export class ClearAll implements Action {
    readonly type = ActionTypes.CLEAR_ALL;
    constructor() {}
  }

  /**
   * Action to clear criteria of a AirSearchCriteria
   */
  export class ClearSelection implements Action {
    readonly type = ActionTypes.CLEAR_SELECTION;
    constructor() {}
  }
}

/**
 * List of action types for the AirSearchCriteria store
 */
export declare type AvailableActions =
  | Actions.Set
  | Actions.AddAndSelect
  | Actions.AddAndActiveAndSelect
  | Actions.AddAndActive
  | Actions.Add
  | Actions.Select
  | Actions.SelectActiveCriterias
  | Actions.ClearSelection
  | Actions.ClearAll;
