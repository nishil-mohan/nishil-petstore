import {createFeatureSelector, createSelector, MemoizedSelector} from '@ngrx/store';
import {AvailableStores} from '@otter/store';
import {adapter} from './air-search-criteria.reducer';
import {Model, State} from './air-search-criteria.state';

export const selectAirSearchCriteriaState: MemoizedSelector<object, State> = createFeatureSelector(AvailableStores.airSearchCriteria);

const selectors = adapter.getSelectors();

/** select the array of AirSearchCriteria ids */
export const selectAirSearchCriteriaIds = createSelector(selectAirSearchCriteriaState, selectors.selectIds);

/** select the array of AirSearchCriterias */
export const selectAllAirSearchCriteria = createSelector(selectAirSearchCriteriaState, selectors.selectAll);

/** select the dictionary of air search entities */
export const selectAirSearchCriteriaEntities: MemoizedSelector<object, {[x: string]: Model}> = createSelector(selectAirSearchCriteriaState, selectors.selectEntities);

/** select the total AirSearchCriteria count */
export const selectAirSearchCriteriaTotal = createSelector(selectAirSearchCriteriaState, selectors.selectTotal);

/** select the list of selected airSearchCriteria Id */
export const selectCurrentAirSearchCriteriaId = createSelector(selectAirSearchCriteriaState, (state) => state.selectedSearchCriteriaId);

/** select the list of selected airSearchCriteria */
export const selectCurrentAirSearchCriteria = createSelector(
  selectAirSearchCriteriaEntities,
  selectCurrentAirSearchCriteriaId,
  (airSearchCriteria, id): Model | null => (id ? airSearchCriteria[id] : null)
);

export const selectActiveSearchCriteriaIds = createSelector(selectAirSearchCriteriaState, (state) => {
  return state.activeSearchCriteriaIds;
});

export const selectActiveSearchCriterias = createSelector(selectAirSearchCriteriaState, (state) => {
  return state.activeSearchCriteriaIds.map((id) => {
    return state.entities[id];
  });
});
