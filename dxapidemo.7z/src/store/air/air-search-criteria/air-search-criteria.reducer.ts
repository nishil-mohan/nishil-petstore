import {AirSearchCriteria} from '@dapi/sdk/models';
import {createEntityAdapter, EntityAdapter} from '@ngrx/entity';
import * as crc32 from 'crc-32';

import {ActionTypes, AvailableActions} from './air-search-criteria.actions';
import {Model, State, StateDetails} from './air-search-criteria.state';

export const adapter: EntityAdapter<Model> = createEntityAdapter<Model>();

export const initialState: State = adapter.getInitialState<StateDetails>({
  selectedSearchCriteriaId: null,
  activeSearchCriteriaIds: []
});

// TODO: Should it be in the SDK ?
// TODO: implement a better checksum
export const generateSearchCrc = (searchCriteria: AirSearchCriteria) => crc32.str(JSON.stringify(searchCriteria)).toString();

/**
 * Reducer of the airSearchCriteria store
 */
export function reducer(state: State = initialState, action: AvailableActions) {
  switch (action.type) {
    case ActionTypes.ADD_AND_SELECT: {
      const model: Model = {id: generateSearchCrc(action.payload), ...action.payload};
      const newState = adapter.addOne(model, state);
      return {...newState, selectedSearchCriteriaId: model.id};
    }
    case ActionTypes.ADD_AND_ACTIVE: {
      const model: Model = {id: generateSearchCrc(action.payload), ...action.payload};
      const newState = adapter.addOne(model, state);
      return {...newState, activeSearchCriteriaIds: [...newState.activeSearchCriteriaIds, model.id]};
    }
    case ActionTypes.ADD_AND_ACTIVE_AND_SELECT: {
      const model: Model = {id: generateSearchCrc(action.payload), ...action.payload};
      const newState = adapter.addOne(model, state);
      return {
        ...newState,
        activeSearchCriteriaIds: [...newState.activeSearchCriteriaIds, model.id],
        selectedSearchCriteriaId: model.id
      };
    }

    case ActionTypes.SET: {
      const models: Model[] = action.payload.map((criteria) => ({id: generateSearchCrc(criteria), ...criteria}));
      return adapter.addMany(models, initialState);
    }

    case ActionTypes.ADD: {
      const model: Model = {id: generateSearchCrc(action.payload), ...action.payload};
      return adapter.addOne(model, state);
    }

    case ActionTypes.SELECT: {
      return {...state, selectedSearchCriteriaId: action.payload.id};
    }

    case ActionTypes.CLEAR_ALL: {
      return initialState;
    }

    case ActionTypes.CLEAR_SELECTION: {
      return {...state, selectedSearchCriteriaId: null};
    }

    default:
      return state;
  }
}
