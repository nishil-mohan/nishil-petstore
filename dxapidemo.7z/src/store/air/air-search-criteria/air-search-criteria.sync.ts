import {reviveAirSearchCriteria} from '@dapi/sdk/models';
import {Serializer} from '@otter/core';
import {adapter, initialState} from './air-search-criteria.reducer';
import {Model, State} from './air-search-criteria.state';

export const storageSync: Serializer<State> = {
  deserialize: (rawObject: any) => {
    if (!rawObject || !rawObject.ids) {
      return initialState;
    }
    const storeObject = adapter.getInitialState(rawObject);
    for (const id of rawObject.ids) {
      // TODO should be updated after https://rndwww.nce.amadeus.net/git/projects/DZ/repos/sdk/pull-requests/215/overview
      storeObject.entities[id] = {...rawObject.entities[id], ...reviveAirSearchCriteria(rawObject.entities[id])} as Model;
    }
    return storeObject;
  }
};
