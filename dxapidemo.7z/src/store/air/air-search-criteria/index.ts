import {ModuleWithProviders, NgModule} from '@angular/core';
import {StoreModule} from '@ngrx/store';

import {AvailableStores} from '@otter/store';

import {AIR_SEARCH_CRITERIA_REDUCER_REGISTRATION_TOKEN, AIR_SEARCH_CRITERIA_REDUCER_TOKEN, airSearchCriteriaReducerProvider} from './air-search-criteria.providers';

export {Actions, ActionTypes, AvailableActions} from './air-search-criteria.actions';

export * from './air-search-criteria.reducer';
export * from './air-search-criteria.selectors';
export * from './air-search-criteria.state';
export * from './air-search-criteria.sync';

export interface CustomAirSearchCriteriaReducer {
  airSearchCriteriaReducer?: any;
}

@NgModule({
  imports: [StoreModule.forFeature(AvailableStores.airSearchCriteria, AIR_SEARCH_CRITERIA_REDUCER_REGISTRATION_TOKEN)],
  providers: [airSearchCriteriaReducerProvider]
})
export class AirSearchCriteriaModule {
  public static forRoot(reducers?: CustomAirSearchCriteriaReducer): ModuleWithProviders {
    const providers = [];
    // custom reducers
    if (reducers && reducers.airSearchCriteriaReducer) {
      providers.push({provide: AIR_SEARCH_CRITERIA_REDUCER_TOKEN, useValue: reducers.airSearchCriteriaReducer});
    }
    return {ngModule: AirSearchCriteriaModule, providers: providers};
  }
}
