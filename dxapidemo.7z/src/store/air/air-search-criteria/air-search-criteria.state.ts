import {AirSearchCriteria} from '@dapi/sdk/models';
import {EntityState} from '@ngrx/entity';
import {StateModel} from '@otter/core';

/**
 * AirSearchCriteria model
 */
export interface Model extends StateModel, AirSearchCriteria {}

/**
 * AirSearchCriteria state details
 */
export interface StateDetails {
  /** Selected AirOffer ID */
  selectedSearchCriteriaId: string | null;

  activeSearchCriteriaIds: string[];
}

/**
 * State of the airSearchCriteria store
 */
export interface State extends EntityState<Model>, StateDetails {}
