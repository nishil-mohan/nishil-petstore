package com.upgrad.election;

import java.util.HashMap;
import java.util.Map;

public class HashmapPollCount extends AbstractElectionPolling {

	private Map<Integer,Integer> voterMap =new HashMap<Integer,Integer>(1000);
	private Map<Integer,Integer> candidateMap =new HashMap<Integer,Integer>(100);
	
	@Override
	public void addRecord(Integer voterid, Integer candidateId) {
		voterMap.put(voterid, candidateId);
		candidateMap.merge(candidateId, 1, Integer::sum);
	}

	@Override
	public Integer findCandidate(Integer voterId) {
		return voterMap.get(voterId);
	}

	@Override
	public Integer countPolls(Integer candidateid) {
		return candidateMap.get(candidateid);
	}

}
