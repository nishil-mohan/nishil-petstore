package com.upgrad.election;

public class DAPollCounter extends AbstractElectionPolling {

	private Integer[] voterArray =new Integer[999999];
	private Integer[] candidateArray =new Integer[999];
	
	public void addRecord(Integer voterid, Integer candidateId) {
		voterArray[voterid]=candidateId;
		Integer polls=candidateArray[candidateId];
		if(polls==null){
			polls=0;
		}
		polls=polls+1;
		candidateArray[candidateId]=polls;
	}
	
	public Integer findCandidate(Integer voterId) {
		int candidateId=voterArray[voterId]; 
		return candidateId;
	}

	
	public Integer countPolls(Integer candidateid) {
		return candidateArray[candidateid]; 
	}
	

}
