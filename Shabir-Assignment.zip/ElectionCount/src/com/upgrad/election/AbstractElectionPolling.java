package com.upgrad.election;

public abstract class AbstractElectionPolling {

	
	public abstract void addRecord(Integer voterid, Integer candidateId);
	
	public  abstract Integer findCandidate(Integer voterId);
	
	public  abstract Integer countPolls(Integer candidateid);
	
	
}
