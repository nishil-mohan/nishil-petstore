package com.upgrad.election;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/*
 * Worst case running time for Direct addressing method: O(1)
 * Worst case running time for Hash method: O(n)
 * 
 */


public class ElectionPolling {

	public static void main (String s[]){
		
		ElectionPolling polling=new ElectionPolling();

		System.out.print("Press D for Direct Addressing and H for Hash : ");
		
		Scanner scanner =new Scanner(System.in);
		
		AbstractElectionPolling electionCounter =choseoption(scanner); 
		
		if(electionCounter == null) {
			System.out.println("Please provide a valid input");
			return;
		}
		
		File file = polling.FileLoading();
		try {
		Scanner fileScanner = new Scanner(file);
			while (fileScanner.hasNextLine()) {
				String record = fileScanner.nextLine(); 
				String[] recordArray=record.split("\t");
				int voterId=Integer.parseInt(recordArray[0]);
				int candidateId=Integer.parseInt(recordArray[1]);
				electionCounter.addRecord(voterId,candidateId);
				//System.out.println(record);
			}
			fileScanner.close();
		}
	   catch (IOException e) {
	  		e.printStackTrace();
		}
		
		System.out.print("Please enter the voter id to see the candidate chosen :");
		int voterid=scanner.nextInt();
		Integer candidateId=electionCounter.findCandidate(voterid);
		System.out.printf("Candidate opted by %s is %s \n",voterid,candidateId);
			
		
		System.out.print("Enter the candidate for the polling status :");
		int candidate= scanner.nextInt();
		Integer pollingcount=electionCounter.countPolls(candidate);
		System.out.printf("Total votes polled for the candidate %s is %s .",candidate ,pollingcount);
		scanner.close();
	}


	private static AbstractElectionPolling choseoption(Scanner scanner) {
		String option=scanner.next();
		if("D".equals(option)){
			return new DAPollCounter();
		}else if ("H".equals(option)) {
			return new HashmapPollCount();
		}
		else {
			return null;
		} 
	} 	
	

	private  File FileLoading(){
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("input/data.txt").getFile());
		return file;
	}
}
